// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara


Readme file for General ODBC driver download GODBC.ZIP file. Folder and their contents are listed. This will give you can an idea of what to find where. More details are available in the CPP files of the respective projects.

The projects have been built using Visual C++ 6.0 under Windows 2000 professional/server. All the projects (.dsp) are part of the main workspace (.dsw ) residing in the root folder GODBC

Make sure you have the following header files, import libraries and DLLs on your system
1. SQL.H
2. SQLTYPES.H
3. SQLEXT.H
4. ODBCINST.H
5. ODBC32.LIB & ODBC32.DLL
6. ODBCCP32.LIB & ODBCCP32.DLL

You can obtain these from Microsoft site as a part of Platform SDK or MDAC kit


List of folders and description:
================================

GODBC                  - Root folder containing the workspace. All the projects are part of this single workspace (GODBC.dsw)

GODBC\Client           - Contains a simple ODBC client that can be used to test your driver as well as connect to any ODBC data source. The client operates in 2 modes. When _SHOW_FULL_RESULTS is defined, it will just fetch the first col value of the first row. This has been done to create a minimum code snippet required to access an ODBC data source. Otherwise it will show you all the rows and cols on console window in a simple fashion. All data is retrieved as char to keep things simple and only the first 64 bytes are shown on screen.

GODBC\Common           - Contains files which have been used to create the ODBC driver or dummy server. These are generic in nature and ODBC driver is another application for them. The folder contains the SOCK folder and XML folder as described below.

GODBC\Common\SOCK      - Contains the socket client class and the socket server class. The client class is a generic socket client. The XSOCKCLI example uses this class for a simple test client. The class is used by the ODBC driver to communicate with the server over sockets. Similarly the server class is a generic socket server. The XSOCKSVR example uses this class for a simple socket server. If you want you can can add this socket server to your DBMS server to allow it to listen to the requests coming from the ODBC driver. Win32 provides a number of models for building a socket server, depending upon the nature of application and scalability requirements. I have mentioned the book for this in the article. Also I believe that the IO completion port model is the most scalable although it is a little complex to implement also. You can find examples in MS Platform SDK.

GODBC\Common\XML       - Contains the XML lexer (XMLLex), parser (XMLParse) and tree (XMLTree). The lexer combines with the parser to recieve streamed XML and convert it to an XMLTree object model. The tree model then is used to navigate through the tree and process the data. The ODBC driver uses the XMLTree first to construct an XML SOAP request and sends it to server using sockets. The server responds with an XML/SOAP response which is parsed using the parser and then served to client with necessary conversions. The format for request response can be obtained from the article or the CPP files. This folder also contains the SOAP helper which are functions to help you build SOAP requests and responses

GODBC\ODBCDrv0         - Contains code for skeleton driver. Basically to create the first driverDLL, know about registration and nature of communication between the Client, Driver Manager and the Driver.

GODBC\ODBCDrv1         - Contains code for a real-life ODBC driver, which can be tailored as per you DBMS. Note that the entire functionality has not been implemented but is enough to get you data into most standard ODBC clients like MS Query, Word, Excel, provided your server is capable to process SQL statements of reasonable complexity. Note that the header file is a very important starting point for understanding this driver.

GODBC\ODBCReg          - Contains code for registering/unresgitering the ODBC driver. As explained in the article this can also be done manually using registry editor (REGEDIT)

GODBC\BasicSock        - Contains a test socket client and server using the code snippets given in the article. This is to demonstrate a handshake (with a hello string) between a socket client and socket server. It does not use the socket class as used by XSOCKCLI or XSOCKSVR and is there just to support the snippets given in the article. For all practical purpose u will need to work through XSOCKCLI and XSOCKSVR. The projects TESTCLI and TESTSVR are based on files in this folder.

GODBC\XSOCKCLI         - Contains code for a simple socket client built using the socket client class from the COMMON\SOCK folder. The driver acts as a socket client hence understanding this will help you understand the working of sockets from within the driver

GODBC\XSOCKSVR         - Contains code for a simple socket server built using the socket server class from the COMMON\SOCK folder. Can be used to serve XSOCKCLI or our sample driver also. The DBMS server acts as a socket server to serve data to the ODBC driver. You have to get your actual DBMS ready to understand and server your ODBC driver in SOAP-XML format, till this is done you can use this as a dummy server and the driver can interact with it and receive hard-coded but meaningful responses for most common calls. Given our sample driver and this server, you should be able to get data in MS Query, Excel and word. This gives you an idea on what changes to make into your DBMS.

GODBC\EXE             - Contains all the sample EXE and DLLs at one place for quick start. More on this in QuickStart.txt file. This folder contains the debug version. The release version is contained in the RELEASE folder under this folder




Trying it out
=============

Goto the EXE folder under GODBC. 

Checking basic socket communication
-----------------------------------

1. Run TESTSVR in a console window. It will appear to wait. Goto another console window and run TESTCLI. Both will immediately terminate giving a message "Done.".

Checking socket client & server with SOAP-XML communication
-----------------------------------------------------------

1. Run XSOCKSVR in a console window. It will start waiting for connection on port 9999. Goto another console window and run XSOCKCLI. It will confirm and send request in way the driver is expected to send. The server will respond accrodingly. You will able to see the request response on the screen as well as in the log files XSOCKCLI.LOG and XSOCKSVR.LOG


Checking XML DOM and parser
---------------------------

1. Run the XMLTEST.EXE file without any params. This will test the lexer followed by parser and then the building of tree using DOM. You can specify an XML file on the command-line if you want. The lexer and parser would be tested on this file


Resgistering your first driver
------------------------------

1. Run ODBCREG with the following params /i "General ODBC driver 0" ODBCDRV0.DLL [current path]. The full command will look something like this
   ODBCREG /i "General ODBC Driver 0" ODBCDRV0.DLL C:\PROJECTS\GODBC\EXE
Now you can goto to ODBC Applet in Control Panel or administrative tools and create a FILEDSN. You should get a few debug prompts from the skeleton driver.


Registering our real-life driver
--------------------------------

1. Run ODBCREG with the following params /i "General ODBC driver 1" ODBCDRV1.DLL [current path]. The full command will look something like this
   ODBCREG /i "General ODBC Driver 1" ODBCDRV1.DLL C:\PROJECTS\GODBC\EXE
Now you can goto to ODBC Applet in Control Panel or administrative tools and create a FILEDSN. You should now be able to use our client and see the data from our sample server. Note that for creating a DSN using our ODBCDRV1 u will need to have XSOCKSVR running, since it will try and communicate with the server to check the connection.


Seeing the complete ODBC work -- server, driver, my client and general clients like MS Excel
---------------------------------------------------------------------------------------------

1. See QuickStart.txt file 


Few more points
===============

All projects have the following settings
Debug -> Output -> Intermeditary files -> DEBUG folder ( inside the project directory )
Debug -> Output -> Final file (EXE or DLL) -> project folder 
Release -> Output -> Intermeditary files -> RELEASE folder ( inside the project directory )
Release -> Output -> Final file (EXE or DLL) -> RELEASE folder ( inside the project directory )

so u will get the DEBUG version of the output file in the project folder while RELEASE version in the RELEASE folder. 

Also the projects have been compiled using Warning level 3


all the best

Vikash K Agarwal
INDIA
(vikash_agarwal@hotmail.com)
