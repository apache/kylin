// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

// ----------------------------------------------------------------------------
//
// File:		XMLLNLST.CPP
//
// Purpose:     Implementation of the XMLNodeList class used by the parser to
//				perform reductions
//
// Author:		Vikash K Agarwal
//
// Notes:		This is NOT a full-fledged node-list class
//				and is only used as an intermediary for reduction
//
// ---------------------------------------------------------------------------

// -------------------------- include files ---------------------------
#include <xmltree.hpp>

// --------------------------------------------------------------------------
// constructor
// --------------------------------------------------------------------------

XMLNodeList::XMLNodeList ( XMLNode* pNode )
{
    vFirstNode = pNode;
    vLastNode = pNode;
}

// -----------------------------------------------------------------------
// copy constructor for a node list ( is no more required by new parser )
// -----------------------------------------------------------------------

XMLNodeList::XMLNodeList ( const XMLNodeList & pSrc )
{
    XMLNode * node;

    // initialize the basic data
    vFirstNode = 0;
    vLastNode = 0;

    // loop to copy the entire list of nodes from src to this
    for ( node = pSrc.vFirstNode; node; node = node->GetNextSibling())
        AppendSibling ( new XMLNode (*node));
}

// ---------------------------------------------------------------------------
// destructor
// ---------------------------------------------------------------------------

XMLNodeList::~XMLNodeList ()
{
    XMLNode* node;

    // loop to destroy the list
    while ( vFirstNode ) {

        // store node
        node = vFirstNode;

        // store next node
        vFirstNode = node->GetNextSibling();

        // detach node from list
        node->DetachSelf();

        // now delete the node
        delete node;
    }
}
 
// -----------------------------------------------------------------------
// to add a next sibling to the list of nodes
// -----------------------------------------------------------------------

XMLNode * XMLNodeList::AppendSibling( XMLNode* pNode )
{
    // add depending on whether there is already an existing node
    if ( vFirstNode == 0 ) {

        vFirstNode = pNode;
        vLastNode = pNode;
    }
    else {

        // attach it to last node
        vLastNode->vNextSibling = pNode;

        // set the previous & next sibling
        pNode->vPrevSibling = vLastNode;  pNode->vNextSibling = 0;

        // attach it to last node
        vLastNode = pNode;
    }

    return vLastNode;
}

// ---------------------------------------------------------------------------
// appends the entire list to specified node and clears the original
// ---------------------------------------------------------------------------

bool XMLNodeList::MoveToNode ( XMLNode* pNode )
{
    // precaution
    if ( pNode == 0 )
        return false;

    // check if a list actually exists
    if ( vFirstNode ) {

        // append the list to node, can fail bcoz of node type
        if ( pNode->AppendChildNodes ( vFirstNode ) != vFirstNode )
            return false;

        // clear the original copy
        vFirstNode = 0;
        vLastNode = 0;

    }   // else is an empty list, so nothing needs to be done

    return true;
}


// End-of-file

