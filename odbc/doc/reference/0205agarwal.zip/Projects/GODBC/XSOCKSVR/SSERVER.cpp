// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

// ----------------------------------------------------------------------------
//
// File:    SSERVER.CPP
//
// Author:  Vikash K Agarwal
//
// Notes:   Socket server for testing the socket class (TSocket - XSOCLSVR.CPP)
//          The server receives the XML/SOAP requests either
//          from the test client (XSOCKCLI) or from our driver.
//
//          The server class allows to specify a function which is called
//			after receiving the request from the client.
//
//          The request is parsed and fed to DOM. If the parsing 
//			fails a SOAP fault response is generated and sent to 
//			the client. Otherwise the request is analysed and call
//			served by the appropriate function. For example
//			SQLTables request is served by the function SQLTables.
//			The response is prepared in SOAPXML and sent back
//			using the streaming capabilities of XMLNode.
//
//          Apart from the lexer parser and node class required
//			for XML processing of any form, this project also
//			includes the files SS_SOAP.CPP and SS_METHODS.CPP.
//			SS_SOAP.CPP provides the SOAP helper functions over
//			and above those provided by XMLNode. Say creation of
//			ENVELOPE-HEADER-BODY request is done in a single
//			function using the functions of XMLNode. Similarly
//			checking the request for being a valid SOAP request
//			requires checking of the mandatory SOAP tags, this
//			is done in a single function. This is important since
//			both the driver and server require such an helper
//			file above the XMLParser and XMLNode class
//				
//			SS_METHODS.CPP file is essentially an emulator
//			for response expected from the server. The pur

//          If u have doubts about the communication 
//          from the server u can use this server and check
//          that out. On the other hand, if u have doubts
//          about the driver, u can use XSOCKCLI example and
//          check it out.    
//
//          The request response session can be dumped to screen
//          as well to a log file
//
//          This server should be enough to get ur data in most of
//			the clients including MS Query, Word, Excel.
//
// ----------------------------------------------------------------------------

// ------------------------------- include files ------------------------------
#include <io.h>
#include <conio.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <winsock2.h>

#include <xmllex.hpp>
#include <xmlparse.hpp>

#include "sock_svr.hpp"								// socket server class

// ------------------------------ local defines -------------------------------
#define			_LOG_FILE_NAME				"xsocksvr.log"

// ---------------------- functions from SS_SOAP.CPP --------------------------
bool            SOAPCheckReq                ( XMLNode* pNode, XMLNode** pMethod, XMLNode** pStmt, XMLNode** pVars );
bool            SOAPCreateFaultResp         ( XMLNode* pMethod, XMLNode** pResp );

// --------------------- functions from SS_METHODS.CPP ------------------------
bool			CreateMethodResponse        ( XMLNode* pMethod, XMLNode** pResp );

// --------------------------- log functions ----------------------------------
void			DumpBufferToScreen			( char* pHeader, XMLNode* pNode, char* pBuf, int pBufSize );
void			ResetLogFile				( void );
void			DumpBufferToLog				( char* pHeader, XMLNode* pNode, char* pBuf, int pBufSize );

// -------------------------- server functions --------------------------------
short			ProcessSystemMsgs           ( void );
int				ParseRequest				( char* pReqBuf, int pReqSize, XMLNode** pReq );
short			SendResponse                ( TSocket* pSock, char* pReqBuf, int pReqSize );

// --------------------------- main testing function --------------------------
void            TestSockServer              ( void );

// ------------------------------- global vars --------------------------------
bool		g_fDumpReqToScr			= true;
bool		g_fDumpReqToLog			= true;
bool		g_fDumpRespToScr		= true;
bool		g_fDumpRespToLog		= true;		


// --------------------------------------------------------------------
// to dump a buffer to screen, usually for debugging
// --------------------------------------------------------------------

void DumpBufferToScreen ( char* pHeader, XMLNode* pNode, char* pBuf, int pBufSize )
{
    int i;

    // show header if one has been specified
    if( pHeader && *pHeader ) printf( "\n%s: ", pHeader );

	// check if source is buffer or a DOM node
	if ( pNode )
		pNode->StreamToFile ( 0, _FILE_STDOUT, stdout );				// stream node to stdout
	else
		for ( i = 0; i < pBufSize; i ++ )  putchar ( pBuf[i]);			// show buffer char by char

    // newline
    fprintf ( stdout,  "\n" );
}

// --------------------------------------------------------------------
// to reset the contents of the log file
// --------------------------------------------------------------------

void ResetLogFile ( void )
{
    FILE*       f;

    // open the log file, "w" will reset the contets
    f = fopen ( _LOG_FILE_NAME, "w" );

    if ( f ) 
        // close the file
        fclose ( f );
}

// --------------------------------------------------------------------
// to save the buffer to a log file, for later analysis
// --------------------------------------------------------------------

void DumpBufferToLog ( char* pHeader, XMLNode* pNode, char* pBuf, int pBufSize )
{
	int			h;	

    // open the log file
	h = _open ( _LOG_FILE_NAME, _O_CREAT | _O_RDWR | _O_APPEND | _O_TEXT, _S_IWRITE );

    // check
    if ( h != -1 ) {

        // dump header 
        if ( pHeader && *pHeader ) {

            _write ( h, "--------\n", 9 );
            _write ( h, pHeader, strlen ( pHeader ));
            _write ( h, "\n", 1 );
            _write ( h, "--------\n", 9 );
        }

		// check if source is buffer or a DOM node
		if ( pNode )
			pNode->StreamToFile ( 0, _FILE_DISK_FILE, ( void* )h );				// stream node to file

        else
			_write ( h, pBuf, pBufSize );								// dump the buffer 

        // separator
        _write ( h, "\n\n", 2 );
        
        // close the file
        _close ( h );           
    }
}

// --------------------------------------------------------------------
// callback to process other system messages like quit etc
// --------------------------------------------------------------------

short ProcessSystemMsgs( void )
{
    // check if a key has been pressed
    if( kbhit()) {      

        int c;

        // show message on screen -- debug
        printf("a key hit\n" );

        // get the key
        if(( c = getch()) == 0 ) c = getch();

        // check if q
        if( c == 'q' )
            return SOCKSTATUS_MSG_SRVRSTOP;             // stop the server

        else if( c == 'b' )
            return SOCKSTATUS_MSG_CLIENTSTOP;           // stop this client    
    }
    
    return 0;
}

// --------------------------------------------------------------------
// parse the request recd into an XML node object
// --------------------------------------------------------------------

int	ParseRequest ( char* pReqBuf, int pReqSize, XMLNode** pReq )
{
    XMLParser   xp ( pReqBuf, pReqSize );					// feed string response to parser

    // feed to parser
    if (( *pReq = xp.GetObjNode ()) == NULL ) {

		// debug 
        printf( "\nError: Request could not be parsed\n\n" );       
        return 0;
    }

    return 1;                               // success
}

// --------------------------------------------------------------------
// callback to process request & send the response
// --------------------------------------------------------------------

short SendResponse ( TSocket* pSock, char* pReqBuf, int pReqSize )
{
	// this is callback from the socket class
	// 1. the request is parsed using ParseRequest
	// 2. the request is checked for SOAP format using SOAPCheckReq
	// 3. the response is generated using CreateMethodResponse
	// 4. the response is streamed back using XMLNode streaming

    short		fault = 0;
    XMLNode*	nReq;
	XMLNode*	nMethod;
    XMLNode*	nStmt;
    XMLNode*	nVars;
    XMLNode*	nResponse;

    // check if full dump of request required
    if ( g_fDumpReqToScr )
        DumpBufferToScreen ( "Request dump", NULL, pReqBuf, pReqSize );

    // check if full dump of request required in log file
    if ( g_fDumpReqToLog )
        DumpBufferToLog ( "Request dump", NULL, pReqBuf, pReqSize );



	
	// parse the request received
    if ( ParseRequest ( pReqBuf, pReqSize, &nReq ) != 1 ) {
		fault = 1;
        SOAPCreateFaultResp ( NULL, &nResponse );					// set fault flag & create fault response
	}

	// check the request recd.
	else if ( SOAPCheckReq ( nReq, &nMethod, &nStmt, &nVars ) != 1 ) {
		fault = 1;
        SOAPCreateFaultResp ( NULL, &nResponse );					// set fault flag & create fault response
	}

	// create the method response as per the method type
    else if ( CreateMethodResponse ( nMethod, &nResponse ) != 1 ) {
        fault = 1;
        SOAPCreateFaultResp ( NULL, &nResponse );
    }



	// debug
    printf( "\nResponse type: %s\n",  ( fault == 1 ) ? "fault" : "valid" );

    // check if full dump of request required
    if ( g_fDumpRespToScr )
		DumpBufferToScreen ( "Response dump", nResponse, NULL, 0  );

    // check if full dump of request required in log file
    if ( g_fDumpRespToLog )
        DumpBufferToLog  ( "Response dump", nResponse, NULL, 0  );



	// signature --- start signature
	pSock->WriteSignature ();

	// stream the prepared response via socket
	nResponse->StreamToFile ( 0, _FILE_SOCK_SERVER, pSock );

	// signature --- end signature
	pSock->WriteSignature ();



	// debug
    printf( "\n-------------------- Done ----------------------\n" );

    return SOCKSTATUS_IO_COMPLETE;
}

// --------------------------------------------------------------------
// test the socket class as a server
// --------------------------------------------------------------------

void TestSockServer ( void )
{
    TSocket* ss;

	// banner
    printf ( "Starting server ... listening on port 9999 (q to quit)\n" );
   
	// initialize the socket server and specify the SendResponse as UDF
    ss = new TSocket( INADDR_ANY, 9999, ProcessSystemMsgs, SendResponse );

	// start servicing the clients, requests will be sent to UDF SendResponse for streaming the response
    ss->ServiceClients ();

    delete ss;
}


// --------------------------------------------------------------------
// main entry point function
// --------------------------------------------------------------------

void main ( void )
{
	// to test socket as a server
    TestSockServer();
}
