// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

// ----------------------------------------------------------------------------
//
// File:    XMLPHELP.CPP
//
// Author:  Vikash K Agarwal
//
// Notes:   Implentation of the XMLParser and XResult class.
//
//          The main parser class is XMLParse, core of which
//          is generated using YACC and is derived as follows
//          XMLPARSE.Y ----> XMLPARSE.CXX -----> XMLPARSE.CPP
//          Other methods including the reduction action is
//          present in this file ie parser help file
//
//          The XResult class is also implemented in this file.
//          This is the datatype for all operations/reductions 
//          occuring on tokens. This class wraps the XMLNode 
//          class, XMLNodeList class and a simple string token
//
// ----------------------------------------------------------------------------

// ------------------------------ include files -------------------------------
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#include <common.hpp>
#include <xmllex.hpp>
#include <xmlparse.hpp>

// ----------------------------------------------------------------------------
// XResult class implementation
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// constructor
// ----------------------------------------------------------------------------

XResult::XResult ( void )
{
    uToken      = NULL;
    uNode       = NULL;
    uNodeList   = NULL;
}

// ----------------------------------------------------------------------------
// destructor
// ----------------------------------------------------------------------------

XResult::~XResult()
{
    delete uToken;
    delete uNode;
    delete uNodeList;
}

// ----------------------------------------------------------------------------
// assignment operator overloaded
// ----------------------------------------------------------------------------

XResult& XResult::operator=(XResult & pXResult)
{
    // note 
    // this function does not behave like normal equals operator
    // the speciality is that it moves the pointer values from
    // the source to the target rather than creating copy.
    // this has been done to gain speed since otheriwse parsing is
    // infeasible for very long files. The other option is to create
    // a function and use the function in the YACC template, to
    // avoid changing the behaviour of equal operator.
    // Also note that for this to work other changes are required in
    // the template. 
    // 1. the transfer of token from yylval to yyval has to use something else
    // 2. the transfer of value to yyval must be done as default reduction
    // 3. the final reduction value is available in yyv[1] and not yyval

    // check if left and right operand are one and the same
    if (this == &pXResult )
        return *this;

    // reset any existing values in LHS
    Reset ();

    // transfer token string
    if ( pXResult.uToken ) {

        uToken = pXResult.uToken;
        pXResult.uToken = NULL;
    }

    // transfer node
    if (pXResult.uNode) {

        uNode = pXResult.uNode;
        pXResult.uNode = NULL;
    }

    // transfer nodelist
    if (pXResult.uNodeList) {

        uNodeList = pXResult.uNodeList;
        pXResult.uNodeList = NULL;
    }

    return *this;
}

// ----------------------------------------------------------------------------
// reset the class, delete all existing values
// ----------------------------------------------------------------------------

void XResult::Reset ( void )
{
    if ( uToken ) {
        delete uToken;
        uToken = NULL;
    }

    if ( uNode ) {
        delete uNode;
        uNode = NULL;
    }

    if ( uNodeList ) {
        delete uNodeList;
        uNodeList   = NULL;
    }
}

// ----------------------------------------------------------------------------
// create copy of token value from specified class
// ----------------------------------------------------------------------------

void XResult::CopyTokenValue ( XResult& pXResult )
{
    // note
    // this function is specially used to transfer token from yylval to yyval
    StrMake ( uToken, pXResult.uToken );
}

// ----------------------------------------------------------------------------
// called by constructor or by user if he wants to specify the params later
// ----------------------------------------------------------------------------

void XMLParser::InitParserParams ( char* pBuffer, int pSize )
{
    // init vars to zero
    memset ( this, 0, sizeof(XMLParser));                         

    // initialize the lexer params
    vLex.InitLexerParams ( pBuffer, pSize, this );

    // initialize token holder for lexer
    vLex.InitTokenHolder ( &( yylval.uToken ));

}


// ----------------------------------------------------------------------------
// CXMLParse class implementation
// ----------------------------------------------------------------------------

XMLParser::XMLParser ( char* pBuffer, int pSize ) : vLex ( 0, 0, 0 )
{
    // initialize parser and the contained lexer
    InitParserParams ( pBuffer, pSize );
}


// -----------------------------------------------------------------------
// to set the internal error message using va arg list
// -----------------------------------------------------------------------

bool XMLParser::VarErrMsg ( const char* pErrMsg, va_list pArgs )
{
    vActionResult = false;

    vsprintf ( vszErrMsg , pErrMsg, pArgs );

    return false;             
}

// -----------------------------------------------------------------------
// to set the internal error message
// -----------------------------------------------------------------------

bool XMLParser::SetErrMsg ( const char* pErrMsg, ...)
{
    va_list         args;

    va_start ( args, pErrMsg );

    VarErrMsg ( pErrMsg, args );

    va_end ( args );

    return false;
}


// -----------------------------------------------------------------------
// to parse a text for addtion to element, NOT called as a YACC action
// -----------------------------------------------------------------------

void XMLParser::ReduceText ( char* pText )
{
/*    int x = strlen ( pText )-1;

    while (*(  pText+x ) == 32 && x > 0 ) x --;

    *( pText+x ) = 0;*/
}

// -----------------------------------------------------------------------
// action for YACC rule. to create an attr & add to previous chain if any
// -----------------------------------------------------------------------

bool XMLParser::ActionReduceAttr ( XResult& pResult, XResult* pAttrList, XResult* pAttrNameStr, XResult* pAttrValueStr )
{
    XMLNode *   node;

    // reduction with previously existsing chain occurs in 3 steps
    // 1. node is created and there is no previous node or chain
    // 2. node is created and combined with a previously reduced node to make a chain
    // 3. node is created and combined with a previously reduced chain

    // create a new attribute node and check successful creation
    if (( node = XMLNode::CreateAttribute ( &( pAttrNameStr->uToken ), &( pAttrValueStr->uToken ))) != 0 ) {

        // reset the result object
        pResult.Reset();

        // Existing attributes reduced may be either
        // 1, No nodes
        // 2. One node existing as a node
        // 3. More than one node existing as chain/list

        // check if something is there already reduced
        if( pAttrList ) {

            // one reduced node exists
            if( pAttrList->uNode ) {

                // combine both nodes to form a list
                pResult.uNodeList = new XMLNodeList ( pAttrList->uNode ); pAttrList->uNode = 0;

                // add the currently created node
                if( pResult.uNodeList->AppendSibling( node ) != node )
                    return false;             // errmsg already set in ImpObj

                return ( vActionResult = true );
            }

            // a list of nodes exist
            else if ( pAttrList->uNodeList ) {

                // add the list to current result
                pResult.uNodeList = pAttrList->uNodeList;  pAttrList->uNodeList = 0;

                // add it to node list directly
                if( pResult.uNodeList->AppendSibling( node ) != node )
                    return false;             // errmsg already set in ImpObj

                return ( vActionResult = true );
            }
        }

        // nothing exists from previos reductions so make it a fresh node
        pResult.uNode = node;

        return ( vActionResult = true );
    }
    else return ( vActionResult = false );
}

// -----------------------------------------------------------------------
// action for YACC rule. to create an element w/o attr & add to previous chain if any
// -----------------------------------------------------------------------

bool XMLParser::ActionReduceElement ( XResult& pResult, XResult* pElementList, bool pfEmptyElement, XResult* pStartTagStr, XResult* pAttrs, XResult* pTagTextStr, XResult* pChildNodeList, XResult* pEndTagStr )
{
    XMLNode*    node;

    // reduction with previously existsing chain occurs in 3 steps
    // 1. node is created and there is no previous node or chain
    // 2. node is created and combined with a previously reduced node to make a chain
    // 3. node is created and combined with a previously reduced chain

    // check if element is of the form <TAG/> or <TAG xxx />
    if ( pfEmptyElement == false ) {

        // compare the start and end tag
        if ( pEndTagStr->uToken == NULL || strcmp ( pStartTagStr->uToken, pEndTagStr->uToken ) != 0 )
            return SetErrMsg ( "Start and end tags are not same %s, %s.", pStartTagStr->uToken, pEndTagStr->uToken ? pEndTagStr->uToken : "(null)" );
    }

    // check for text and parse it for trimming etc.
    if ( pTagTextStr && pTagTextStr->uToken )  ReduceText ( pTagTextStr->uToken );

    // create a new element node with text if necessary
    if (( node = XMLNode::CreateElement ( &( pStartTagStr->uToken ), &( pTagTextStr->uToken ))) == 0 )
        return vActionResult = false;

    // check if their is a sub-node or list of sub-nodes to be added
    if ( pChildNodeList ) {

        // check if there is a single node to be added
        if ( pChildNodeList->uNode ) {

            // add the node to the newly created node
            if ( node->AppendChildNodeBeforeX ( pChildNodeList->uNode, 0 ) != pChildNodeList->uNode )
                return ( vActionResult = false );

            pChildNodeList->uNode = 0;
        }

        //  check if there is a list of sub-nodes
        else if( pChildNodeList->uNodeList ) {

            // add the the entire node list to node
            if( pChildNodeList->uNodeList->MoveToNode( node ) == false )
                return ( vActionResult = false );

            // the entire contents of list have been consumed but the list object
            // itself remains, so delete it manually
            delete pChildNodeList->uNodeList;
            
            pChildNodeList->uNodeList = 0;
        }
    }

    // check if the its an element with attributes
    if ( pAttrs ) {

        // check if there is one attribute to be added
        if ( pAttrs->uNode ) {

            // add the attr-node to the element
            node->AppendChildNodeBeforeX ( pAttrs->uNode, 0 );
            pAttrs->uNode = 0;
        }

        // check if there is an attribute list to be added
        else if ( pAttrs->uNodeList ) {

            // add the entire list to node
            if ( pAttrs->uNodeList->MoveToNode ( node ) == false )
                return ( vActionResult = false );

            // the entire contents of list have been consumed but the list object
            // itself remains, so delete it manually
            delete pAttrs->uNodeList;
            pAttrs->uNodeList = 0;
        }
    }

    // reset the result object
    pResult.Reset ();

    // Existing elements reduced may be either
    // 1, No nodes
    // 2. One node existing as a node
    // 3. More than one node existing as chain/list

    // check if their is previous chain to which this node is to be appended
    if ( pElementList ) {

        // one reduced node exists
        if( pElementList->uNode ) {

            // combine both nodes to form a list
            pResult.uNodeList = new XMLNodeList ( pElementList->uNode ); pElementList->uNode = 0;

            // add the currently created node
            if ( pResult.uNodeList->AppendSibling ( node ) != node )
                return false;     // errmsg already sent

            return ( vActionResult = true );
        }

        // a list of nodes exist
        else if ( pElementList->uNodeList ) {

            // add the list to current result
            pResult.uNodeList = pElementList->uNodeList;  pElementList->uNodeList = 0;

            // add it to node list directly
            if ( pResult.uNodeList->AppendSibling ( node ) != node )
                return false;         // errmsg already sent

            return ( vActionResult = true );
        }
    }

    // nothing exists from previos reductions so make it a fresh node
    pResult.uNode = node;

    return ( vActionResult = true );
}

// -----------------------------------------------------------------------
// action for reduction/transformation of elements to element list
// -----------------------------------------------------------------------

bool XMLParser::ActionReduceElementList ( XResult& pResult, XResult* pElementList, XResult* pNode )
{
    // reset the result object
    pResult.Reset();

    // one reduced node exists, combine both nodes to form a list
    if ( pElementList->uNode ) {

        // create a node list in result with previous node
        pResult.uNodeList = new XMLNodeList ( pElementList->uNode ); pElementList->uNode = 0;

        // add the current node
        pResult.uNodeList->AppendSibling( pNode->uNode ); pNode->uNode = 0;

        return ( vActionResult = true );
    }

    // a list of nodes exist
    else if ( pElementList->uNodeList ) {

        // add the list to current result
        pResult.uNodeList = pElementList->uNodeList;  pElementList->uNodeList = 0;

        // add it to node list directly
        pResult.uNodeList->AppendSibling( pNode->uNode ); pNode->uNode = 0;

        return ( vActionResult = true );
    }
    else return ( vActionResult = false );
}

// -----------------------------------------------------------------------
// action for reduction/transformation of root to DOM document, now not that relevant
// -----------------------------------------------------------------------

bool XMLParser::ActionReduceRoot ( XResult & pDest, XResult* pSrc )
{
    // reset the result object
    pDest.Reset();

    // check for a valid root element
    if ( !pSrc->uNode )
        return SetErrMsg ("Parse error, stream could not be reduced to a single node.");

    // copy ( move ) values to destination
    pDest = *pSrc;

    return ( vActionResult = true );
}


// -----------------------------------------------------------------------
// to parse the buffer and get the result as a node
// -----------------------------------------------------------------------

XMLNode* XMLParser::GetObjNode ( void )
{
    XMLNode*    x;

    // call the LALR parser rotuine
    if ( Parse () == false )                         
        return NULL;

    // the net result of reduction
    x = yyv[1].uNode;

    // clean-up yyv so that it doesn't detruct this node later-on
    yyv[1].uNode = NULL;

    return x;
}

// -----------------------------------------------------------------------
// to get the next token in yylval
// -----------------------------------------------------------------------

int XMLParser::LexToken ( void )
{
    return vLex.GetNextToken ();
}

// End-of-file

