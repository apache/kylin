// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

// ---------------------------------------------------------------------------------
//
// File:    XMLTREE.CPP
//
// Author:  Vikash K Agarwal
//
// Notes:   Implementation for XMLNode class
//          All node types whether element, attribute or text inside an
//          element, all are encapsulated within this class and treated
//          as a node type. 
//
//			The structure of the node class is such that it can maintain
//			itself as part of tree as well as contain a child link list.
//
//			The atributes are maintained as a child link list while itself
//			is connected to the tree of elements using Parent, Child Node and
//			siblings. For sub-element link list both the head and tail is maintained. 
//			For attributes link list only the head is maintained.
//
//			Special note: The text of an element is NOT the nodeValue as 
//			would typically be expected, instead it is the nodeValue of
//			the first child element. This design is to accomodate mixed content
//			inside a node ie text. So to access a text of an element the
//			code would be node->first child node->node value and NOT
//			node->node value
//
//			Special Note: The class is also designed to do streaming of
//			the DOM prepared in it. It can stream 
//			1. as a socket server - _XML_STREAM_SOCK_SERVER should be defined
//			during compile so that it uses the socket server class and the 
//			function StreamToFile would require _FILE_SOCK_SERVER as file type parameter.
//			2. as a socket client - _XML_STREAM_SOCK_CLIENT and _FILE_SOCK_CLIENT
//			3. to a disk file     - _XML_STREAM_FILE and _FILE_DISK_FILE
//			4. to stdout          - _XML_STREAM_FILE and _FILE_DISK_FILE
//
//          XMLNodeList is internally used by the XMLParse class
//          during reduction process. This is not a full-fledged 
//          node list class
// ----------------------------------------------------------------------------------


// -------------------------- include files ---------------------------
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#include <common.hpp>
#include <xmltree.hpp>

#ifdef _XML_STREAM_SOCK_SERVER

#include <winsock2.h>
#include <mswsock.h>
#include <sock_svr.hpp>             // include socket server for streaming

#endif


#ifdef _XML_STREAM_SOCK_CLIENT

#include <winsock.h>
#include "sock_cli.hpp"             // include socket client for streaming

#endif

#ifdef _XML_STREAM_FILE

#include <io.h>

#endif

// -----------------------------------------------------------------------
// to add a child node before node X, if NULL then at the end
// -----------------------------------------------------------------------

XMLNode* XMLNode::AppendChildNodeElementBeforeX ( XMLNode* pNode, XMLNode* pX )
{
    // check for valid paramter
    if ( pNode == NULL )   
        return NULL;

    // set parent for specified node
    pNode->vParentNode = this;

    // set previous sibling
    if ( pX )   
        pNode->vPrevSibling = pX->vPrevSibling; 
    else 
        pNode->vPrevSibling = this->vLastChildNode;

    // set the next sibling
    pNode->vNextSibling = pX;

    // connect the previous sibling to self or make it first child
    if ( pNode->vPrevSibling )  
        pNode->vPrevSibling->vNextSibling = pNode; 
    else 
        this->vFirstChildNode = pNode;

    // connect the next sibling to self or make it the last child
    if ( pNode->vNextSibling ) 
        pNode->vNextSibling->vPrevSibling = pNode; 
    else  
        this->vLastChildNode = pNode;

    return pNode;
}

// -----------------------------------------------------------------------
// to add a child node of type TEXT before node X, if NULL then at the end
// -----------------------------------------------------------------------

XMLNode* XMLNode::AppendChildNodeTextBeforeX ( XMLNode* pNode, XMLNode* pX )
{
    // check the node type, the parent element should be an ELEMENT
    if ( vNodeType == XML_NODE_ELEMENT )
        return AppendChildNodeElementBeforeX ( pNode, pX );

    return SetErrMsg ( "Text node can only be added to an element node" );
}

// -----------------------------------------------------------------------
// to add a child node of type ATTRIBUTE before X, if NULL then at the end
// -----------------------------------------------------------------------

XMLNode* XMLNode::AppendNodeAttributeBeforeX ( XMLNode* pNode, XMLNode* pX )
{
    XMLNode* lNode;

    // check for valid node
    if( pNode == NULL || pNode->vNodeName == NULL )
        return SetErrMsg( "Invalid attribute node or attribute name" );

    // check for valid positioning node
    if( pX ) {

        if(  pX->vNodeType != XML_NODE_ATTRIBUTE )
            return SetErrMsg( "Position node is not an attribute" );

        if( pX->vParentNode != this )
            return SetErrMsg( "Position node is not within child list" );
    }

    // check if attribute already exists
    if( FindAttribute ( pNode->vNodeName ))
        return SetErrMsg( "Duplicate attribute" );

    // set parent for specified node
    pNode->vParentNode = this;

    // set previous sibling
    if( pX ) 
        pNode->vPrevSibling = pX->vPrevSibling;
    else {
        // get the last attribute if any
        for( lNode = vFirstAttribute; lNode != 0 && lNode->vNextSibling != 0; lNode = lNode->vNextSibling );

        // make it the previous sibling
        pNode->vPrevSibling = lNode;
    }

    // set the next sibling
    pNode->vNextSibling = pX;

    // connect the previous sibling to self or make it first child
    if( pNode->vPrevSibling )  
        pNode->vPrevSibling->vNextSibling = pNode; 
    else 
        this->vFirstAttribute = pNode;

    // connect the next sibling to self
    if( pNode->vNextSibling ) 
        pNode->vNextSibling->vPrevSibling = pNode;

    return pNode;
}

// -----------------------------------------------------------------------
// appends a chain of elements as children to this
// -----------------------------------------------------------------------

XMLNode* XMLNode::AppendChildNodesElement ( XMLNode* pNode )
{
    XMLNode* lNode;

    // loop thru the fresh chain and set the parent for each
    for( lNode = pNode; lNode != NULL; lNode = lNode->vNextSibling ) {

        // should not have a parent else something is wrong
        if( lNode->vParentNode )
            return SetErrMsg( "Node in list already has a parent" );

        lNode->vParentNode = this;
    }

    // loop thru the fresh chain and find the last node in it
    for( lNode = pNode; lNode->vNextSibling != 0; lNode = lNode->vNextSibling );

    // check if their is an existing chain
    if( vFirstChildNode ) {

        // attach it after the last node
        vLastChildNode->vNextSibling = pNode;  pNode->vPrevSibling = vLastChildNode;

        // set the last node as last node of the fresh chain
        vLastChildNode = lNode;
    }
    else {
        // attach it as a fresh chain
        vFirstChildNode = pNode;  vLastChildNode = lNode;
    }

    return pNode;
}

// -----------------------------------------------------------------------
// appends a chain of attributes as children to this
// -----------------------------------------------------------------------

XMLNode* XMLNode::AppendChildNodesAttribute ( XMLNode* pNode )
{
    XMLNode* lNode;

    // loop thru the fresh chain and set the parent for each
    for( lNode = pNode; lNode != 0; lNode = lNode->vNextSibling ) {

        // should not have a parent else something is wrong
        if( lNode->vParentNode )
            return SetErrMsg ( "Attribute in list already has a parent" );

        lNode->vParentNode = this;
    }

    // check if their is an existing chain
    if( vFirstAttribute ) {

        // loop thru and find last attribute
        for( lNode = vFirstAttribute; lNode->vNextSibling != 0; lNode = lNode->vNextSibling );

        // attach it after the last attribute
        lNode->vNextSibling  = pNode;  pNode->vPrevSibling = lNode;
    }
    else vFirstAttribute = pNode;    // make it a fresh chain

    return pNode;
}

// -----------------------------------------------------------------------
// delete the specified node, node of element type
// -----------------------------------------------------------------------

bool XMLNode::DeleteChildNodeElement ( XMLNode* pNode )
{
    // check if the node is valid
    if( pNode == NULL )
        return false;

    // check if the node is actually a child node to this
    if( pNode->vParentNode != this ) {

        SetErrMsg( "Node is not a valid child" );

        return false;
    }

    // connect prev sibling to next else set the first sibling to next
    if( pNode->vPrevSibling )  pNode->vPrevSibling->vNextSibling = pNode->vNextSibling;
    else pNode->vParentNode->vFirstChildNode = pNode->vNextSibling;

    // connect next sibling to prev else set the last sibling to prev
    if( pNode->vNextSibling )  pNode->vNextSibling->vPrevSibling = pNode->vPrevSibling;
    else pNode->vParentNode->vLastChildNode = pNode->vPrevSibling;

    // detach node from parent
    pNode->vParentNode = 0;

    // the node can now be safely deleted
    delete pNode;

    return true;
}

// -----------------------------------------------------------------------
// to remove the specified attribute from list
// -----------------------------------------------------------------------

bool XMLNode::DeleteNodeAttribute ( XMLNode* pNode )
{
    // check for valid paramter
    if( pNode == NULL || pNode->vNodeType != XML_NODE_ATTRIBUTE ) {

        SetErrMsg( "Invalid node or node is not attribute" );

        return false;
    }

    // check for parent connection
    if( pNode->vParentNode != this ) {

        SetErrMsg( "Attribute is not a valid child" );

        return false;
    }


    // set the next sibling of previous sibling
    if( pNode->vPrevSibling )   pNode->vPrevSibling->vNextSibling = pNode->vNextSibling;

    // set the previous sibling of the next sibling
    if( pNode->vNextSibling )   pNode->vNextSibling->vPrevSibling = pNode->vPrevSibling;

    // check if this is the only attribute
    if( pNode == vFirstAttribute ) vFirstAttribute = pNode->vNextSibling;

    // now delete the node
    delete pNode;

    return true;
}

// -----------------------------------------------------------------------
// sets the internal error message
// -----------------------------------------------------------------------

XMLNode* XMLNode::SetErrMsg ( const char* pErrMsg, ...)
{
    va_list     args;

    va_start (args, pErrMsg);

    // allocate if buffer does not exist
    if ( vErrMsg == NULL )
        vErrMsg = new char[256];

    // create message
    vsprintf ( vErrMsg , pErrMsg, args );

    // ?? debug
    //MessageBox ( NULL, vErrMsg, "XMLTree Debug", MB_OK );

    // done
    va_end (args);

    return NULL;
}

// -----------------------------------------------------------------------
// constructor for a fresh node
// -----------------------------------------------------------------------

XMLNode::XMLNode ( int pNodeType, const char* pNodeName, const char* pNodeValue )
{
    memset ( this, 0, sizeof(XMLNode));

    // check if node type is valid
    if ( pNodeType != XML_NODE_ELEMENT && pNodeType != XML_NODE_ATTRIBUTE && pNodeType != XML_NODE_TEXT )
        return;

    // set node type
    vNodeType = pNodeType;

    // create storage for node name and copy
    if ( pNodeName ) {

        switch (pNodeType) {

            case XML_NODE_TEXT:

                // original behavior StrMake (vNodeName, "#text");
                vNodeName = NULL;
                break;

            default:

                // create copy of the specified node name
                StrMake (vNodeName, pNodeName);
                break;
        }
    }

    // create storage for node value and copy
    if ( pNodeValue ) {

        switch ( pNodeType ) {

            case XML_NODE_TEXT:
            case XML_NODE_ATTRIBUTE:
                StrMake ( vNodeValue, pNodeValue );
                break;
        }
    }
}

// -----------------------------------------------------------------------
// constructor for a fresh node, uses the specified pointer
// -----------------------------------------------------------------------

XMLNode::XMLNode ( int pNodeType, char** pNodeName, char** pNodeValue )
{
    // note
    // this constructor is specially designed for speed
    // since it will use the specified values rather than creating a copy
    // also it will compulsorily set the caller values to NULL so that
    // destruction takes place only thru this class

    memset ( this, 0, sizeof(XMLNode));

    // check if node type is valid
    if ( pNodeType != XML_NODE_ELEMENT && pNodeType != XML_NODE_ATTRIBUTE && pNodeType != XML_NODE_TEXT )
        return;

    // set node type
    vNodeType = pNodeType;

    // create storage for node name and copy
    if ( pNodeName ) {

        switch (pNodeType) {

            case XML_NODE_TEXT:

                vNodeName = NULL;
                break;

            default:

                // use the specified string as node name
                vNodeName = *pNodeName;

                // reset caller
                *pNodeName = NULL;
                break;
        }
    }

    // create storage for node value and copy
    if ( pNodeValue ) {

        switch ( pNodeType ) {

            case XML_NODE_TEXT:
            case XML_NODE_ATTRIBUTE:

                // use the specified string as node value
                vNodeValue = *pNodeValue;

                // reset caller
                *pNodeValue = NULL;
                break;
        }
    }
}

// -----------------------------------------------------------------------
// copy constructor for a node, 
// -----------------------------------------------------------------------

XMLNode::XMLNode ( const XMLNode& pNodeSrc )
{
    XMLNode* oTemp;
    XMLNode* oNode;

    // copy basic data like node type, name, value etc.

    vNodeType = pNodeSrc.vNodeType;

    StrMake ( vNodeName, pNodeSrc.vNodeName );
    StrMake ( vNodeValue, pNodeSrc.vNodeValue );

    // parent node will always be null along with next and previous sibling
    vParentNode = 0; vNextSibling = 0, vPrevSibling = 0;

    // initialze the attribute list and child nodes
    vFirstAttribute = 0; vFirstChildNode = 0; vLastChildNode = 0;

    // if node is element than copy attributes and child elements
    if( pNodeSrc.vNodeType == XML_NODE_ELEMENT ) {

        // loop to copy all the attributes
        for( oTemp = pNodeSrc.vFirstAttribute; oTemp; oTemp = oTemp->GetNextSibling()) {

            // create a fresh node
            oNode = new XMLNode ( oTemp->vNodeType, oTemp->vNodeName, oTemp->vNodeValue );

            // append the attribute at the chain end
            AppendNodeAttributeBeforeX( oNode, NULL );
        }

        // copy the child elements including text-only node
        if( pNodeSrc.vNodeType == XML_NODE_ELEMENT ) {

            // loop to copy all the child elements
            for( oTemp = pNodeSrc.vFirstChildNode; oTemp; oTemp = oTemp->GetNextSibling()) {

                // create a fresh node
                oNode = new XMLNode (*oTemp);

                // append the child at the end of chain
                AppendChildNodeElementBeforeX( oNode, 0 );
            }
        }
    }
}

// -----------------------------------------------------------------------
// destructor for  the node
// -----------------------------------------------------------------------

XMLNode::~XMLNode()
{
    // loop to delete all the children one by one
    while( vLastChildNode ) {

        DeleteChildNodeElement( vLastChildNode );
    }

    // loop to delete all the attributes and break on error
    while (vFirstAttribute ) {

        DeleteNodeAttribute( vFirstAttribute );
    }

    // delete the dynamically allocated name and value

    delete vNodeName;
    delete vNodeValue;

    // clear the error message
    if ( vErrMsg )
        delete vErrMsg;
}

// -----------------------------------------------------------------------
// to add a child node of any type, before node X or at the end
// -----------------------------------------------------------------------

XMLNode* XMLNode::AppendChildNodeBeforeX (XMLNode* pNode, XMLNode* pX )
{
    // precaution
    if ( pNode == NULL )
        return SetErrMsg( "NULL Node!");

    // check for valid
    if( vNodeType != XML_NODE_ELEMENT)
        return SetErrMsg ("Child nodes can only be added to elements");

    // check for node type
    switch (pNode->vNodeType) {

        case XML_NODE_ELEMENT:
            return AppendChildNodeElementBeforeX ( pNode, pX );

        case XML_NODE_TEXT:
            return AppendChildNodeTextBeforeX ( pNode, pX );

        case XML_NODE_ATTRIBUTE:
            return AppendNodeAttributeBeforeX ( pNode, pX );

        default:
            return SetErrMsg( "Invalid node type" );
    }
}

// -----------------------------------------------------------------------
// appends a chain of attributes or elements as children to this
// -----------------------------------------------------------------------

XMLNode* XMLNode::AppendChildNodes ( XMLNode* pNode )
{
    // precaution
    if (vNodeType != XML_NODE_ELEMENT )
        return SetErrMsg( "Child nodes can only be added to elements" );

    // check for node type
    switch (pNode->vNodeType) {

        case XML_NODE_ELEMENT:
        case XML_NODE_TEXT:
            return AppendChildNodesElement (pNode);

        case XML_NODE_ATTRIBUTE:
            return AppendChildNodesAttribute (pNode);

        default:
            return SetErrMsg( "List contains invalid node type" );
    }
}

// -----------------------------------------------------------------------
// to add a next sibling attr or element to this node. to provide list like functions
// -----------------------------------------------------------------------

XMLNode* XMLNode::AppendSibling ( XMLNode* pNode )
{
    bool        flgTypeCheck;
    bool        flgCmpCheck;
    XMLNode*    lNode;

    // precaution
    if( !pNode )
        return 0;

    // addition will depend upon the type of node

    // to add an element or text node to the chain
    if ( pNode->vNodeType == XML_NODE_ELEMENT || pNode->vNodeType == XML_NODE_TEXT ) {

        // move to end of chain of elements/text
        for ( flgTypeCheck = true, lNode = this;
                ( flgTypeCheck = ( lNode->vNodeType == XML_NODE_ELEMENT || lNode->vNodeType == XML_NODE_TEXT )) == true  &&
                ( lNode->vNextSibling != 0 ) ;
            lNode = lNode->vNextSibling );

        // check if chain is fully made of elements and text
        if ( !flgTypeCheck )
            return SetErrMsg( "Node should be element/text for addition to list" );

        // set to same parent if any, should not have a parent if used for chain addition
        if( lNode->vParentNode ) {

            pNode->vParentNode = lNode->vParentNode;
            pNode->vParentNode->vLastChildNode = pNode;
        }
        else pNode->vParentNode = 0;

        // set the previous & next sibling
        pNode->vPrevSibling = lNode;  pNode->vNextSibling = 0;

        // attach it to last node
        lNode->vNextSibling = pNode;

        return pNode;
    }

    // to add an attribute node to the chain
    else if( pNode->vNodeType == XML_NODE_ATTRIBUTE ) {

        // move to end of chain of attributes
        for (flgTypeCheck = true, flgCmpCheck = true, lNode = this;
                (flgTypeCheck = ( lNode->vNodeType == XML_NODE_ATTRIBUTE )) == true  &&
                (flgCmpCheck = ( strcmp (lNode->vNodeName, pNode->vNodeName ) != 0 )) == true &&
                (lNode->vNextSibling != 0 ) ;
            lNode = lNode->vNextSibling );

        // check if chain is fully made of attributes or a similar attr is already there
        if( !flgTypeCheck )
            return SetErrMsg( "Node should be attribute for addition to list" );

        if( !flgCmpCheck )
            return SetErrMsg( "Duplicate attribute in list" );

        // set to same parent if any
        pNode->vParentNode = lNode->vParentNode;

        // set the previous & next sibling
        pNode->vPrevSibling = lNode;  pNode->vNextSibling = 0;

        // attach it to last node
        lNode->vNextSibling = pNode;

        return pNode;
    }

    return SetErrMsg( "Invalid node type" );
}

// -----------------------------------------------------------------------
// to detach the node from parent, previous and next sibling
// -----------------------------------------------------------------------

void XMLNode::DetachSelf ( void )
{
    // set the next sibling of previous sibling

    if (vPrevSibling )
        vPrevSibling->vNextSibling = vNextSibling;

    // set the previous sibling of the next sibling

    if (vNextSibling)
        vNextSibling->vPrevSibling = vPrevSibling;

    // check for a parent

    if (vParentNode) {

        // check the node type

        if (vNodeType == XML_NODE_ATTRIBUTE ) {

            // check if first attribute

            if (vParentNode->vFirstAttribute == this )
                vParentNode->vFirstAttribute = 0;

        } else {

            // check if this is the first element

            if  (vParentNode->vFirstChildNode == this)
                vParentNode->vFirstChildNode = vNextSibling;

            // check if this is the last element

            if (vParentNode->vLastChildNode == this)
                vParentNode->vLastChildNode = vPrevSibling;
        }
    }
}

// --------------------------------------------------------------------------
// to locate an attribute with a specific name
// --------------------------------------------------------------------------

XMLNode* XMLNode::FindAttribute ( const char* pAttrName )
{
    XMLNode* node;

    if ( pAttrName == NULL || *pAttrName == 0 )
        return NULL;

    // start at first attribute
    node = vFirstAttribute;

    while ( node ) {

        // compare
        if ( stricmp ( node->vNodeName, pAttrName ) == 0 )
            return node;

        // move next
        node = node->vNextSibling;
    }

    // not found
    return NULL;
}


// -----------------------------------------------------------------------
// helper function, to parse & cvt a string with special chars like <
// -----------------------------------------------------------------------

char* XMLNode::CvtMarkersInStr ( char* pStr )
{
    int     i1, i2, n;              // general counters
    int     nLesser, nAnd;          // counter for each marker
    char*   newstr;                 // final string if any change else NULL is returned

    // precaution
    if( pStr  == NULL )  return 0; 
    
    // initialize counters
    nLesser = 0; 
    nAnd = 0;

    // count the number of special chars in string
    for( i1 = 0, n = strlen( pStr ); i1 < n; i1 ++ ) {

        // check the char
        switch( *( pStr + i1 )) {

            // case Left bracket
            case '<':

                nLesser ++;   // increase count
                break;

            case '&':

                nAnd ++;   // increase count
                break;

        }
    }

    // check if any special chars in string
    if( nLesser > 0 || nAnd > 0 ) {

        // allocate a new buffer with enough storage after expanding the special chars
        newstr = new char[ n + (nLesser*3) + ( nAnd*4) + 1 ];

        // now parse the string again & convert
        for ( i1 = 0, i2 = 0; i1 < n; i1 ++ ) {

            // check the char
            switch( *( pStr + i1 )) {

                // case Left bracket
                case '<':

                    memcpy(( newstr + i2 ), "&lt;", 4 ); 
                    i2 += 4;
                    break;

                // case Left bracket
                case '&':

                    memcpy(( newstr + i2 ), "&amp;", 5 ); 
                    i2 += 5;
                    break;

                // no special character
                default:

                    *( newstr + i2 ) = *( pStr + i1 ); 
                    i2 += 1;
                    break;
            }
        }

        // put the end of string marker
        newstr[i2] = 0;

        // return the new string
        return newstr;
    }
    else return pStr;    // no change so original is returned
}


// -----------------------------------------------------------------------
// helper function, to stream a string to file after conversion of markers
// -----------------------------------------------------------------------
                                                                
bool XMLNode::StreamStrToFile ( char* pStr, int pFileType, void* pFileHandle, bool fConvert  )
{
    // note
    // this the magic function which allows streaming to a file, socket or screen
    // it is compiled conditionally so that all the header files are not always
    // required during compilation. It also does the expansion of special characters
    // if specified

    char*   newstr;
    bool    status = false;

    if ( pStr == NULL )  
        return true;

    // either comnvert and use or use directly
    newstr = fConvert ? CvtMarkersInStr( pStr ) : pStr;

#ifdef _XML_STREAM_SOCK_SERVER


    // check if streaming via socket server class is required
    if ( pFileType == _FILE_SOCK_SERVER ) {

        int x1;
        status =  (( TSocket* )pFileHandle)->WriteResponseMsg ( newstr, strlen ( newstr ), x1 ) == SOCKSTATUS_IO_COMPLETE ? true : false;

    }

#endif

#ifdef _XML_STREAM_SOCK_CLIENT


    // check if streaming via socket client class is required
    if ( pFileType == _FILE_SOCK_CLIENT ) {

        int x2;
        status =  (( TSocketClient* )pFileHandle)->SockWriteChunk ( newstr, strlen ( newstr ), x2 );

    }

#endif


#ifdef _XML_STREAM_FILE

    // check if streaming to a file is required
    if ( pFileType == _FILE_DISK_FILE ) {

        int x3;

        x3 = strlen ( newstr );

        status =  _write (( int )pFileHandle, newstr, x3 ) == x3 ? true : false;
    }


#endif


#ifdef _XML_STREAM_STDOUT

    // check if streaming to screen is required
    if ( pFileType == _FILE_STDOUT ) {

        fprintf (( FILE* )pFileHandle, newstr );

        status = true;
    }

#endif

    // check if any conversion has taken place
    if ( fConvert ) {

        // check if a new string was actually allocated
        if( newstr && newstr != pStr )  {  delete[] newstr; newstr = 0; }
    }

    return status;
}

// -----------------------------------------------------------------------
// to stream spaces for indenting
// -----------------------------------------------------------------------

bool XMLNode::StreamSpacesToFile ( int pCount, int pFileType, void* pFileHandle  )
{
    return true;
}


// -----------------------------------------------------------------------
// to stream the entire tree into the specified file
// -----------------------------------------------------------------------

bool XMLNode::StreamToFile ( int pLevel, int pFileType, void* pFileHandle )
{
    int         i = 0;
    XMLNode*    node;

    // indent for proper level
    StreamSpacesToFile ( pLevel*4, pFileType, pFileHandle );

    // check if node type is TEXT
    if ( vNodeType == XML_NODE_TEXT ) {

        // convert and add the text value w.r.t flgRaw
        StreamStrToFile ( vNodeValue, pFileType, pFileHandle, true );

        // text node streaming complete
        return true;

    } else if ( vNodeType == XML_NODE_ATTRIBUTE )  // if node of type attribute something is wrong
        return false;


    // stream the opening tag 
    StreamStrToFile ( "<", pFileType, pFileHandle, false );
    StreamStrToFile ( vNodeName, pFileType, pFileHandle, false );

    // loop to add the attributes
    for( node = vFirstAttribute; node != 0; node = node->GetNextSibling()) {

        // add the attribute name
        StreamStrToFile ( " ", pFileType, pFileHandle, false );
        StreamStrToFile ( node->vNodeName, pFileType, pFileHandle, false );

        // add the attribute value ie quote value quote
        StreamStrToFile ( "=\"", pFileType, pFileHandle, false );
        StreamStrToFile ( node->vNodeValue, pFileType, pFileHandle, true );
        StreamStrToFile ( "\"", pFileType, pFileHandle, false );
    }

    // check if node has children
    if (( node = vFirstChildNode ) != 0 ) {

        // closing bracket for opening tag before streaming child elements
        StreamStrToFile ( ">", pFileType, pFileHandle, false );

        // everything in a single line only if one child & that too TEXT
        if (( node->vNodeType != XML_NODE_TEXT ) ||
            (( node->vNodeType == XML_NODE_TEXT ) &&
             ( node->GetNextSibling() != 0 ))) {

            // put a newline
            StreamStrToFile ( "\r\n", pFileType, pFileHandle, false );

            // recurse to add all the child elements
            for( ; node != 0; node = node->GetNextSibling())   
                if( node->StreamToFile ( pLevel+1, pFileType, pFileHandle ) == false )
                    return false;

            // indent
            StreamSpacesToFile ( pLevel*4, pFileType, pFileHandle );
        }
        else
            StreamStrToFile ( node->vNodeValue, pFileType, pFileHandle, true );

        // close tag
        StreamStrToFile ( "</", pFileType, pFileHandle, false );
        StreamStrToFile ( vNodeName, pFileType, pFileHandle, false );
        StreamStrToFile ( ">", pFileType, pFileHandle, false );
    }
    else
       StreamStrToFile ( "/>", pFileType, pFileHandle, false );
       
    return true;
}


// ----------------------------------------------------------------------------
// to create a fresh element
// ----------------------------------------------------------------------------

XMLNode* XMLNode::CreateElement ( const char* szNodeName, const char* szText )
{
    XMLNode* l_oNodeText;
    XMLNode* l_oNodeElement;

    // check for valid parameter
    if( szNodeName ) {


        // create a fresh element
        l_oNodeElement = new XMLNode ( XML_NODE_ELEMENT, szNodeName, NULL );

        // check if text node is also required
        if( szText && *szText ) {
            // create a text element
            l_oNodeText = new XMLNode ( XML_NODE_TEXT, NULL, szText );

            // append to to element node
            l_oNodeElement->AppendChildNodeBeforeX( l_oNodeText, 0 );
        }

        return l_oNodeElement;
    }
    else return 0;
}


// ----------------------------------------------------------------------------
// to create a fresh element
// ----------------------------------------------------------------------------

XMLNode* XMLNode::CreateElement ( char** szNodeName, char** szText )
{
    XMLNode* l_oNodeText;
    XMLNode* l_oNodeElement;

    // check for valid parameter
    if( szNodeName ) {

        // create a fresh element
        l_oNodeElement = new XMLNode ( XML_NODE_ELEMENT, szNodeName, NULL );

        // check if text node is also required
        if( szText && *szText ) {
            // create a text element
            l_oNodeText = new XMLNode ( XML_NODE_TEXT, NULL, szText );

            // append to to element node
            l_oNodeElement->AppendChildNodeBeforeX ( l_oNodeText, 0 );
        }

        return l_oNodeElement;
    }
    else return 0;
}


// ----------------------------------------------------------------------------
// to create a fresh attribute
// ----------------------------------------------------------------------------

XMLNode* XMLNode::CreateAttribute ( const char* szNodeName, const char* szNodeValue )
{
    XMLNode* l_oNode;

    // check for valid paramter and create a fresh node
    return ( szNodeName ) ? ( l_oNode = new XMLNode ( XML_NODE_ATTRIBUTE, szNodeName, szNodeValue )) : 0;
}


// ----------------------------------------------------------------------------
// to create a fresh attribute
// ----------------------------------------------------------------------------

XMLNode* XMLNode::CreateAttribute ( char** szNodeName, char** szNodeValue )
{
    XMLNode* l_oNode;

    // check for valid paramter and create a fresh node
    return ( szNodeName ) ? ( l_oNode = new XMLNode ( XML_NODE_ATTRIBUTE, szNodeName, szNodeValue )) : 0;
}


// ----------------------------------------------------------------------------
// to create a fresh text node
// ----------------------------------------------------------------------------

XMLNode* XMLNode::CreateText ( const char* szNodeValue )
{
    XMLNode* l_oNode;

    // check for valid paramter and create a fresh node
    return ( szNodeValue ) ? ( l_oNode = new XMLNode ( XML_NODE_TEXT, NULL, szNodeValue )) : 0;
}

// ----------------------------------------------------------------------------
// to create a fresh text node
// ----------------------------------------------------------------------------

XMLNode* XMLNode::CreateText ( char** szNodeValue )
{
    XMLNode* l_oNode;

    // check for valid paramter and create a fresh node
    return ( szNodeValue ) ? ( l_oNode = new XMLNode ( XML_NODE_TEXT, NULL, szNodeValue )) : 0;
}

// End-of-file

