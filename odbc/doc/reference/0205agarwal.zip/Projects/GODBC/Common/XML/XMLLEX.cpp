// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

// ----------------------------------------------------------------------------
//
// File:		XMLLEX.CPP
//
// Purpose:     Implementation of the XMLLex class used by the parser to
//				tokenize an XML stream
//
// Author:		Vikash K Agarwal
//
// Notes:       The class is not required to be accessed separately.
//				It is used by the parser class internally.
//				The XMLTEST project is the testing project for XMLLex, XMLParser and XMLTest
//
// ---------------------------------------------------------------------------

// ------------------------------- include files ------------------------------
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>

#include <common.hpp>
#include <xmllex.hpp>
#include <xmlparse.h>


// -----------------------------------------------------------------------
// to initialize basic lexer data like source buffer, size and parser
// -----------------------------------------------------------------------

void XMLLex::InitLexerParams  ( char* pBuf, int pSize, XMLParser* pParser )
{
    vState              = _LS_INITIAL;                  // maintains the current state defined by state constants _LS
    vLastTokenType      = 0;                            // last token type

    vCurPos             = 0;                            // current position in stream
    vMaxPos             = 0;
    vBuffer             = 0;                            // data stream

    vTokenCurPos        = 0;                            // currently used size for token 
    vTokenMaxSize       = 0;                            // currently allocated size for token
    vTokenBuffer        = 0;                            // holder for the token pointer

    vInError            = false;

    vUserBuffer         = true;

    if ( pBuf ) {

        vBuffer = pBuf;
        vMaxPos = ( pSize <= 0 ) ? strlen ( pBuf ) : pSize;
    }
    else {

        vBuffer = 0;
        vMaxPos = 0;
    }

    vParser = pParser;
}

// -----------------------------------------------------------------------
// constructor that uses input stream 
// -----------------------------------------------------------------------

XMLLex::XMLLex ( char* pBuf, int pSize, XMLParser* pParser )
{
    InitLexerParams ( pBuf, pSize, pParser );                 // init params
}

// -----------------------------------------------------------------------
// to initialize if not done during constructor call or otherwise
// -----------------------------------------------------------------------

void XMLLex::InitLexerState ( void )
{
    vState          = _LS_INITIAL;
    vLastTokenType  = 0;
    vInError        = false;
}

// -----------------------------------------------------------------------
// to initialize the token holder which is directly used by caller parser
// -----------------------------------------------------------------------

void XMLLex::InitTokenHolder ( char** pTokenBuf )
{
    // note
    // this is to provide optimization for speed. The caller provides
    // the placeholder for the token buffer so that the lexer can feed
    // it directly. besides as the need be the lexer can expand the buffer also

    if ( vTokenBuffer == NULL ) {

        // store the token holder
        vTokenBuffer = pTokenBuf;

        // allocate space for token
        *vTokenBuffer = ( char* )calloc ( 1,  MAX_XMLTOKEN_BUFSIZE );

        // set the token buffer size
        vTokenMaxSize = MAX_XMLTOKEN_BUFSIZE;

    } 
    else        
        memset ( *vTokenBuffer, 0, vTokenMaxSize );         // clear any previous buffer

    // reset the token position
    vTokenCurPos = 0;
}



// -----------------------------------------------------------------------
// to add the character to token 
// -----------------------------------------------------------------------

void XMLLex::AddCharToToken ( char pChar )
{
    // note
    // a token is built char by char into the token holder specified by the
    // user - one time. As required the size of holder is increased. The
    // following token automatically used the new size
    // this function complements the AddCurrCharToToken and is used
    // specifically for adding chars after conversion

    // check if the token holder is full

    if ( vTokenCurPos == vTokenMaxSize ) {

        char*       tmp;

        // allocate expanded buffer
        tmp = ( char* )calloc ( 1, vTokenMaxSize + MAX_XMLTOKEN_BUFSIZE + 1 );

        // preserve existing token
        memcpy ( tmp, *vTokenBuffer, vTokenMaxSize );

        // release old buffer
        free( *vTokenBuffer );

        // use the new buffer
        *vTokenBuffer = tmp;

        // set the new size
        vTokenMaxSize += MAX_XMLTOKEN_BUFSIZE;
    }

    // store the specified char
    ( *vTokenBuffer )[vTokenCurPos] = pChar;

    // increment the position holder of token BUT NOT for data stream
    vTokenCurPos++;
}


// -----------------------------------------------------------------------
// to preserve state, last token type and also to add the last part of token
// -----------------------------------------------------------------------

int XMLLex::FinalizeToken ( int pState, int pTokenType )
{
    // check for valid token
    if ( pTokenType > 0 ) {

        // store the state
        if ( pState >= 0 )
            vState = pState;

        // store the token type
        vLastTokenType = pTokenType;
    }

    return pTokenType;
}


// -----------------------------------------------------------------------
// to ignore all whitespaces from the current position
// -----------------------------------------------------------------------

void XMLLex::IgnoreWhiteSpace ( void )
{
    char    c;

    // loop until whitespace or stream end
    while (( c = GetNextChar()) != 0 ) {

        // check if white space
        if ( c != C_SPACE && c != 10 && c != 13 && c != C_TAB )
            break;

        // move to next char
        IncrPos ();
    }
}

// -----------------------------------------------------------------------
// any token starting with '<' is processed by this function
// -----------------------------------------------------------------------

int XMLLex::LesserToken (void)
{
    bool    flgProceed = 1;                     // indication for further proceed
    char    c;                                  // temp char storage
    char    nxtchar;                            // temp char storage
    int     tokentype = 0;                      // local token type
    int     state = _LS_INITIAL;                // local state storage

    // this function will process
    // 1. <tagname> including <tagname    >
    // 2. <tagname/> including <tagname        />
    // 3. <tagname attr1="val1" ....   will be sent upto <tagname only
    // 4. </tagname> including </tagname    >

    // move to second char assuming first char as '<'
    IncrPos(); // ????? original behavious ----- AddCurrCharToToken ();

    nxtchar = GetNextChar ();               // save it ... need to check for '</' situations below

    // check eos
    if ( EndOfStream())
        return SetErrMsg("Unexpected end." );

    // second character can only be
    // 1. front slash    2. valid name start     3. error
    if ( nxtchar == C_SLASH ) {

        IncrPos(); // ????? original behavious ----- AddCurrCharToToken();

            // check eos

        if ( EndOfStream())
            return SetErrMsg ( "Unexpected end." );
    }

    // read the character
    c = GetNextChar ();

    // the next character can only be a valid name start ie after < or </
    if ( !isalpha(c) && !isdigit(c) && c != C_UNDERSCORE )
        return SetErrMsg ( "Invalid char %c after < or </.", c );

    AddCurrCharToToken ();

    // push into token until
    // 1. white space or invalid char     2. front-slash        3. '>'
    while( !EndOfStream ()) {

        // read the current character
        c = GetNextChar ();

        // check if its whitespace or any invalid character for tag name
        // - and . are allowed inside or at end of name
        if( !isalpha(c) && !isdigit(c) && c != C_UNDERSCORE && c != C_HYPHEN && c != C_PERIOD ) {
            flgProceed = 1;
            break;
        }
        else AddCurrCharToToken ();
    }

    // check if proceeding further is possible
    if ( !flgProceed )
        return SetErrMsg ( "Unexpected end after <." );

    // loop to ignore all white space
    while ( !EndOfStream()) {

        // read the current character
        c = GetNextChar ();

        // check if its whitespace
        if ( c != 32 && c != 10 && c != 13 && c != C_TAB) {
            flgProceed = 1;
            break;
        }
        else IncrPos ();
    }

    // check if proceeding further is possible
    if ( !flgProceed )
        return SetErrMsg ( "Unexpected end after <." );

    // after ignoring all spaces it can be
    // 1. end of start tag
    // 2. end of empty element
    // 3. end of end tag
    // 4. start of attribute for the element
    c = GetNextChar ();

    // a complete start or end tag found depending upon the second char in token
    if ( c == C_GREATER ) {

        IncrPos (); // ????? original behavious ----- AddCurrCharToToken();

        // check second ORIGINAL char in token

        if ( nxtchar == C_SLASH ) {

            tokentype = _END_TAG;
            state = _LS_INITIAL;

        } else {

            tokentype = _START_TAG;
            state = _LS_WITHIN_ELEMENTTEXT;
        }

    } else if ( c == C_SLASH ) {

        IncrPos (); // ????? original behavious ----- AddCurrCharToToken();

        if ( EndOfStream())
            return SetErrMsg ( "Unexpected end after /." );

        if ( GetNextChar () != C_GREATER )
            return SetErrMsg ( "Invalid char %c after /.", GetNextChar ());

        IncrPos (); // ????? original behavious ----- AddCurrCharToToken();

        state       = _LS_INITIAL;
        tokentype   = _EMPTY_ELEMENT;
    }

    // only a valid name start
    else if( isalpha(c) || c == C_UNDERSCORE) {

        state       = _LS_WITHIN_STARTTAG;
        tokentype   = _START_TAG_WITH_ATTR;
    }
    else
        return SetErrMsg("Invalid char %c for name start." );

    // return the token after doing internal storage and cleanup
    return FinalizeToken ( state, tokentype );
}

// -----------------------------------------------------------------------
// any special markers starting with amp & and ending with ;
// -----------------------------------------------------------------------

static tToken   sAmpEncoding[] = {

    { C_LESSER,     "lt"    },
    { C_AND,        "amp"   },
    { C_GREATER,    "gt"    },
    { 0,            NULL    },
};

// -----------------------------------------------------------------------
// to process any enocded stuff like &amp; and convert to actual char
// -----------------------------------------------------------------------

int XMLLex::MarkerStringToken (void)
{
    char    c;
    int     i;
    char    buf[MAX_XMLAMP_ENCODING + 1];

    // note
    // 1. although processed separately it is not a separate token for parser
    // 2. it is actually compressing &xxx; into its coressponding char
    // 3. if valid automatically adjusts counters in src stream and token


    memset ( buf, 0, sizeof(buf));

    // precaution
    if ( GetNextChar () != C_AND )
        return 0;

    // move to next char
    IncrPos();

    // loop until ; or termination and get count
    for ( i = 0; ( i < MAX_XMLAMP_ENCODING ) && !EndOfStream (); i++, IncrPos() ) {

        // read the character
        c = GetNextChar ();

        // check for termination of marker with a semi-colon
        if (c == C_SEMICOLON)
            break;

        // check for termination thru a invalid char
        if (!isalpha(c) &&
            !isdigit(c) &&
            (c != C_UNDERSCORE) &&
            (c != C_HYPHEN) &&
            (c != C_PERIOD))
            return SetErrMsg("Semi-colon ; expected." );

        buf[i] = c;
    }

    // check if a proper end was encountered
    if (i == MAX_XMLAMP_ENCODING)
        return SetErrMsg("Semi-colon ; expected - too many characters found." );

    // now check if the marker is valid and detrmine the appropriate char

    tToken*    st = sAmpEncoding;

    // loop to compare with encoded token list
    while (st->uString) {

        // compare
        if (strcmp ( buf, st->uString ) == 0)
            break;

        // next encoded token
        st ++;
    }

    if ( st->uString == 0 )
        return SetErrMsg ( "Unknown token after &" );

    // add the char to token
    AddCharToToken (( char )st->uId );

    // increment the data stream counter beyond the C_SEMICOLON
    IncrPos ();

    return 1;
}

// -----------------------------------------------------------------------
// any string token is processed with this function, can be a name token string
// -----------------------------------------------------------------------

int XMLLex::StringToken ( bool pfValidName, bool pfQuoted, bool pfCvtMarkers )
{
    char c;
    char cEnd = 0;

    // the first parameter pfValidName indicates that it has to be a
    // valid name in XML parlance otherwise it is string. If it is only
    // a string then it can be either quoted or unquoted

    // determine if the end of string has to be quoted
    if ( !pfValidName && pfQuoted ) {

        // determine the ending char like single quote or double quote
        cEnd = GetNextChar ();

        // add char
        IncrPos();             // ????? ---- original behaviour AddCurrCharToToken();
    }

    // loop until end of stream
    while( !EndOfStream()) {

        // read the character
        c = GetNextChar ();         

        // check whether its a plain string or name token to check for termination
        if ( pfValidName ) {          

            // any invalid char terminates the token
            if ( !isalpha(c) && !isdigit(c) && c != C_UNDERSCORE )
                return FinalizeToken( _LS_UNKNOWN, _UNQUOTED_STRING );

        } else {

            // check for end of string with quote or double quotes
            if (( cEnd ) &&( c == cEnd )) {              

                // add char
                IncrPos();             // ????? ---- AddCurrCharToToken();

                // quoted string found
                return FinalizeToken (_LS_UNKNOWN, _QUOTED_STRING) ;
            }

            // check if an embedded marker encountered
            if (( pfCvtMarkers ) && ( c == C_AND )) {               

                // process it as a marker
                if ( MarkerStringToken () !=  0 )
                    continue;

                return false;
            }

            // other possible terminator includes <
            if ( c == C_LESSER ) {            

                if ( cEnd != 0 )        // check if quote required instead of <
                    return SetErrMsg("Incomplete string." );

                    // end of unquoted string

                return FinalizeToken ( _LS_UNKNOWN, _UNQUOTED_STRING );
            }
        }

        // ignore any formatting characters or else add the char to string
        if ( c == 13 || c == 10 || c == C_TAB )    
            IncrPos ();                        // move to next char
        else
            AddCurrCharToToken ();             // add char to string
    }

    // stream ended wihtout a valid string end
    return SetErrMsg ( "Unexpected end." );
}

// -----------------------------------------------------------------------
// to get the next token from the stream w.r.t current pos and state
// -----------------------------------------------------------------------

int XMLLex::GetNextToken (void)
{
    char    ch;

    // return values
    // the token type is returned
    // the actual token value is put inside the place holder specified by user

    // check if any more character left in stream
    if ( EndOfStream())
        return 0;

    // check if a token holder has been specified
    InitTokenHolder ( NULL );

    // loop to extract the value of token
    do {

        // the current character is read and the proper function is called based on
        // 1. the character itself
        // 2. the previos token
        // 3. previous state

        // case whitespace
        // 1. as a part of start tag definition - ignored completely
        // 2. as start of element text - ignored completely
        IgnoreWhiteSpace ();

        ch = GetNextChar ();            // read the current character

        switch (ch) {

        case 0:
            break;

        // case C_LESSER:
        // 1. multiple cases handled by LesserToken
        // 2. error if within start tag

        case C_LESSER:

            // check the state if within start tag
            if ( vState == _LS_WITHIN_STARTTAG )
                return SetErrMsg ( "Invalid char %c for token start", ch );

                return LesserToken ();


        // case C_GREATER only occurs when
        // 1. a startof element contains attributes so closing bracket was left out
        // 2. is part of element text
        // 3. error

        case C_GREATER:

            // if within start tag it marks the end of start tag
            if ( vState == _LS_WITHIN_STARTTAG ) {

                AddCurrCharToToken();
                return FinalizeToken( _LS_WITHIN_ELEMENTTEXT, _END_OF_START_TAG );

            }

            // if within element text then just another char with text
            if ( vState == _LS_WITHIN_ELEMENTTEXT ) {

                AddCurrCharToToken();
                break;
            }

            return SetErrMsg("Invalid char %c for token start.", ch );

        // case C_SLASH only occurs with />
        // 1. when an empty element has attributes & could not be processed as one token
        // 2. is part of element text
        // 3. error

        case C_SLASH:

            if( vState == _LS_WITHIN_STARTTAG ) {

                // add char to token
                IncrPos ();                 // ????? --------- AddCurrCharToToken();

                // next char must be there and should be
                if( !EndOfStream() && (GetNextChar () == C_GREATER) ) {

                    IncrPos ();             // ????? --------- AddCurrCharToToken();
                    return FinalizeToken( _LS_INITIAL, _END_OF_EMPTY_ELEMENT );
                }

                return SetErrMsg("Unexpected end or invalid char after /." );
            }

            // part of text
            if( vState == _LS_WITHIN_ELEMENTTEXT ) {

                AddCurrCharToToken();
                break;
            }

            return SetErrMsg("Invalid char %c for token start /.", ch );

        // case C_EQUAL occurs as
        // 1. a token between attribute name and value
        // 2. as part of element text

        case C_EQUAL:

            // check for state
            if( vState == _LS_WITHIN_STARTTAG ) {

                // check for last token type
                if( vLastTokenType == _UNQUOTED_STRING ) {

                    AddCurrCharToToken();
                    return FinalizeToken( _LS_WITHIN_STARTTAG, _EQUALS );
                }
                else
                    return SetErrMsg("Invalid char = for token start." );
            }
            else if ( vState == _LS_WITHIN_ELEMENTTEXT ) {

                AddCurrCharToToken();
                continue;
            }
            else
                return SetErrMsg("Invalid char = for token start." );

        // case C_QUOTE occurs as
        // 1. a start token for attribute value
        // 2. as part of element text

        case C_QUOTE:
        case C_SNGL_QUOTE:

            // check state
            if ( vState == _LS_WITHIN_STARTTAG ) {

                // check for ;ast token type
                if ( vLastTokenType == _EQUALS ) {

                    // a quoted string token with conversion of markers
                    return StringToken ( false, true, true );
                }
                else
                    return SetErrMsg ( "Invalid char %c for token start.", ch );
            }
            // continue it as part of normal element text

        default:

            // case any string qualifying as
            // 1. attribute name
            // 2. element text
            // 3. unknown or error

            // check for last token and state
            // an equals was returned but no quotes ahead
            if ( vState == _LS_WITHIN_STARTTAG && vLastTokenType == _EQUALS )
                return SetErrMsg ( "Quoted attribute value expected." );

            if ( vState == _LS_WITHIN_STARTTAG )
                return StringToken ( true, false, false );

            return StringToken ( false, false, true );
        }

    } while (!EndOfStream());

    return 0;
}

// -----------------------------------------------------------------------
// to set the internal error message
// -----------------------------------------------------------------------

int XMLLex::SetErrMsg ( const char* pErrMsg, ...)
{
    va_list args;

    va_start (args, pErrMsg);

    vInError = true;

    //vParser->VarErrMsg ( pErrMsg, args );

    va_end (args);

    return 0;
}


// End-of-file

