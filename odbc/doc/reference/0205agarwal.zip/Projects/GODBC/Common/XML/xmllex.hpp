// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

// ----------------------------------------------------------------------------
//
// File:		XMLLEX.HPP
//
// Purpose:     Definition for XMLLex class
//
// Author:		Vikash K Agarwal
//
// Notes:       The class is not required to be accessed separately.
//				It is used by the parser class internally.
//				The XMLTEST project is the testing project for XMLLex, XMLParser and XMLTest
//
// ---------------------------------------------------------------------------

#ifndef XMLLEX_HPP
#define XMLLEX_HPP

// -------------- defines for states fro the lexer ---------------------
#define _LS_UNKNOWN                 -1
#define _LS_INITIAL                 0
#define _LS_WITHIN_STARTTAG         1 
#define _LS_WITHIN_ELEMENTTEXT      2 

// --------------------- internal defines ------------------------------
#define MAX_XMLTOKEN_BUFSIZE        128
#define MAX_XMLAMP_ENCODING         16 

// --------------------------- make parser known -------------------------
class XMLParser;

class XMLLex {
			  
public:

        // constructors

        XMLLex                  ( char* pBuf, int pSize, XMLParser* pParser );

		// destructors

inline  	~XMLLex ();

		// modifiers

        void            InitLexerParams             ( char* pBuf, int pSize, XMLParser* pParser );      // constructor params
        void     	    InitLexerState              ( void );					                        // to start fresh round of 'DOM' seeking
        void            InitTokenHolder             ( char** pTokenBuffer);  	                        // set or initialize the holder for token

inline  void		    IncrPos			            ( void );                   // move to next char in buffer

		// selectors

        int     	    GetNextToken                ( void );                   // get the next token and token value

        bool     	    IsLexError                  ( void );            		// to check if an error occured

		// iterators

		// friends

friend	class 	        XMLParser;

	
protected:

	
private:

        int     	vState;                                 // maintains the current state defined by state constants _LS
        int     	vLastTokenType;                         // last token type

        int     	vCurPos;                                // current position in stream
		int		    vMaxPos;                                // size of buffer
        char*   	vBuffer;                                // data stream

        bool        vUserBuffer;                            // buffer supplied by user, don't delete

        int     	vTokenCurPos;                           // currently used size for token 
        int     	vTokenMaxSize;                          // currently allocated size for token
        char** 	    vTokenBuffer;                           // holder for the token pointer

		XMLParser*  vParser;								// owner of lexer

		bool		vInError;

			// private functions 

        int         MarkerStringToken           ( void );                               // embedded tokens inside strs &xxx;
        int     	LesserToken                 ( void );                               // tokens starting with left angle bracket
        int     	StringToken                 ( bool pfValidName, bool pfQuoted, bool pfCvtMarkers );  // tokens for quoted or unquoted string
        int         FinalizeToken               ( int pState, int pTokenType );         // to finalize before returning   
 
        void     	IgnoreWhiteSpace            ( void );                               // to ignore all whitespace from current point 

        void     	AddCharToToken              ( char pChar);                          // to add the specified character to token
inline  void     	AddCurrCharToToken          ( void );                               // to add the current character to token

inline  char		GetNextChar                 ( void );
		void		ReadFromFile                ( void );
inline  bool     	EndOfStream                 ( void );                    	        // checks for end of stream

        int     	SetErrMsg                   ( const char* pErrMsg, ... );           // sets the internal error message and return '0' as 'token'
};


// ------------------------ structure for storing &xxx; values ----------------
typedef struct idvalue {
    int    uId;
    char*  uString;
} tToken;
  

#include	"xmllex.hxx"

#endif // XMLLEX_HPP

// End-of-file

