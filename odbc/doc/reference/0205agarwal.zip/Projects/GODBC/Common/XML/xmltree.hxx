// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

// ---------------------------------------------------------------------------------
//
// File:    XMLTREE.HXX
//
// Author:  Vikash K Agarwal
//
// Purpose: Inline functions for XMLNode class
//
// ---------------------------------------------------------------------------------

#ifndef XMLTREE_HXX
#define XMLTREE_HXX

inline int XMLNode::GetNodeType (void)              
{ 
	return vNodeType; 
}

inline const char* XMLNode::GetNodeName (void)
{ 
	return vNodeName; 
}

inline const char* XMLNode::GetNodeValue (void)
{ 
	return vNodeValue; 
}

inline XMLNode* XMLNode::GetFirstAttribute (void)
{ 
	return vFirstAttribute; 
}

inline XMLNode* XMLNode::GetFirstChild (void)
{ 
	return vFirstChildNode; 
}

inline XMLNode* XMLNode::GetLastChild (void)
{ 
	return vLastChildNode; 
}

inline XMLNode* XMLNode::GetNextSibling (void)
{ 
	return vNextSibling; 
}

inline XMLNode* XMLNode::GetPrevSibling (void)
{ 
	return vPrevSibling; 
}

#endif // XMLTREE_HXX

// End-of-file

