// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

// ----------------------------------------------------------------------------
//
// File:		XMLPARSE.HXX
//
// Purpose:     Inline functions for XMLParser class
//
// Author:		Vikash K Agarwal
//
// ---------------------------------------------------------------------------

#ifndef XMLPARSE_HXX
#define XMLPARSE_HXX

inline XMLParser::~XMLParser (void)
{
}

#endif // XMLPARSE_HXX

// End-of-file

