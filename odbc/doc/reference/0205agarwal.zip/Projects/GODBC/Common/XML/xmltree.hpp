// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

// ---------------------------------------------------------------------------------
//
// File:    XMLTREE.HPP
//
// Author:  Vikash K Agarwal
//
// Notes:   Definition for XMLNode and XMLNodeList class
//          All node types whether element, attribute or text inside an
//          element, all are encapsulated within this class and treated
//          as a node type. 
//
//			The structure of the node class is such that it can maintain
//			itself as part of tree as well as contain a child link list.
//
//			The atributes are maintained as a child link list while itself
//			is connected to the tree of elements using Parent, Child Node and
//			siblings. For sub-element link list both the head and tail is maintained. 
//			For attributes link list only the head is maintained.
//
//			Special note: The text of an element is NOT the nodeValue as 
//			would typically be expected, instead it is the nodeValue of
//			the first child element. This design is to accomodate mixed content
//			inside a node ie text. So to access a text of an element the
//			code would be node->first child node->node value and NOT
//			node->node value
//
//			Special Note: The class is also designed to do streaming of
//			the DOM prepared in it. It can stream 
//			1. as a socket server - _XML_STREAM_SOCK_SERVER should be defined
//			during compile so that it uses the socket server class and the 
//			function StreamToFile would require _FILE_SOCK_SERVER as file type parameter.
//			2. as a socket client - _XML_STREAM_SOCK_CLIENT and _FILE_SOCK_CLIENT
//			3. to a disk file     - _XML_STREAM_FILE and _FILE_DISK_FILE
//			4. to stdout          - _XML_STREAM_FILE and _FILE_DISK_FILE
//
//          XMLNodeList is internally used by the XMLParse class
//          during reduction process. This is not a full-fledged 
//          node list class
// ----------------------------------------------------------------------------------

#ifndef XMLTREE_HPP
#define XMLTREE_HPP

// ------------------------ node types supported ------------------------
#define XML_NODE_ELEMENT         1
#define XML_NODE_ATTRIBUTE       2
#define XML_NODE_TEXT            3

// ---------------- various file types for streaming --------------------
#define _FILE_SOCK_SERVER           1                       // needs _XML_STREAM_SOCK_SERVER to be defined
#define _FILE_SOCK_CLIENT           2                       // needs _XML_STREAM_SOCK_CLIENT to be defined
#define _FILE_DISK_FILE             3                       // needs _XML_STREAM_FILE to be defined
#define _FILE_STDOUT                4                       // needs _XML_STREAM_FILE to be defined


class XMLNode {
			  
	public:

		// constructors

        	XMLNode ( int pNodeType, const char* pNodeName, const char* pNodeValue );           // constructor
            XMLNode ( int pNodeType, char** pNodeName, char** pNodeValue ); 		            // constructor for speed optimization
        	XMLNode ( const XMLNode & pNodeSrc);                           			            // copy constructor 

		// destructors

        	~XMLNode ( void );                                                      	        // destructor

		// modifiers

        	XMLNode* 	    AppendChildNodeBeforeX  ( XMLNode* pNode, XMLNode* pNext );         // append a child node before node 'Next'
        	XMLNode* 	    AppendChildNodes        ( XMLNode* pNode );                         // appends a chain of attributes or elements as children to this

        	XMLNode* 	    AppendSibling           ( XMLNode* pNode );       					// add a next node/attr to this node, to support list functionality

        	void 		    DetachSelf              ( void );                            		// detach itself from parent and prev/next

		// selectors

inline  	int   		    GetNodeType             ( void );
inline  	const char* 	GetNodeName             ( void );
inline  	const char* 	GetNodeValue            ( void );

inline  	XMLNode*        GetFirstAttribute       ( void );

inline  	XMLNode* 	    GetFirstChild           ( void );
inline  	XMLNode* 	    GetLastChild            ( void );

inline  	XMLNode* 	    GetNextSibling          ( void );
inline  	XMLNode* 	    GetPrevSibling          ( void );

        	XMLNode* 	    FindAttribute           ( const char* pAttrName );                  // to find an attribute by name

		// iterators
            bool            StreamToFile            ( int pLevel, int pFileType, void* pFileHandle );       // to stream to socket, file, screen

		// static functions

static      XMLNode* 	    CreateElement           ( const char* pNodeName, const char* pText );        	// create a new node of type element
static      XMLNode* 	    CreateElement           ( char** pNodeName, char** pText );        	            // create a new node of type element
static      XMLNode* 	    CreateAttribute         ( const char* pNodeName, const char* pNodeValue );   	// create a new node of type attribute
static      XMLNode* 	    CreateAttribute         ( char** pNodeName, char** pNodeValue );   	            // create a new node of type attribute
static      XMLNode* 	    CreateText              ( const char* pNodeValue );                             // create a new node of type text  
static      XMLNode* 	    CreateText              ( char** pNodeValue );                                  // create a new node of type text  

        // friends

friend class XMLNodeList;

	protected:

	private:

        int   		vNodeType;                  // type of node: ele, attr, text
        char* 		vNodeName;                  // node name depending upon type
        char* 		vNodeValue;                 // node value depending upon type

        XMLNode* 	vFirstAttribute;            // start of attributes link list

        XMLNode* 	vParentNode;                // parent node
        XMLNode* 	vNextSibling;               // next child in parents children
        XMLNode* 	vPrevSibling;               // prev child in parents children

        XMLNode* 	vFirstChildNode;            // start of child elements link-list
        XMLNode* 	vLastChildNode;             // end of child elements link-list

        char*       vErrMsg;                    // error message

			// privately used functions

		XMLNode*    SetErrMsg                       ( const char* pErrMsg, ... );

        XMLNode* 	AppendChildNodeElementBeforeX   ( XMLNode* pNode, XMLNode* pX );            // to append a child node of type element before node X or at end
        XMLNode* 	AppendChildNodeTextBeforeX      ( XMLNode* pNode, XMLNode* pX );            // to append a child node of type text before node X or at end
        XMLNode* 	AppendNodeAttributeBeforeX      ( XMLNode* pNode, XMLNode* pX );            // to append an attribute to list bfore attr X or at end

        XMLNode* 	AppendChildNodesElement         ( XMLNode* pNode);                          // appends a chain/list of elements as children to this
        XMLNode* 	AppendChildNodesAttribute       ( XMLNode* pNode);                          // appends a chain/list of attributes as children to this
        bool        DeleteChildNodeElement          ( XMLNode* pNode);                          // delete the specified child node
        bool        DeleteNodeAttribute             ( XMLNode* pNode);                          // deletes the specified attribute node

        char*       CvtMarkersInStr                 ( char* pStr );                             // to convert chars like < to &lt;

        bool        StreamStrToFile                 ( char* pStr, int pFileType, void* pFileHandle, bool fConvert  );       // to convert & stream a string to specified type of file 
        bool        StreamSpacesToFile              ( int pCount, int pFileType, void* pFileHandle  );                      // to stream spaces to specified type of file
};


// -------------------- Node list class defintion ------------------------
// Used to provide a type for a list of nodes or node chain. Automatically 
// checks for valid node types. The destructor and the copy constructor
// are important in providing the node-list type. Only allows extension of
// list at the moment
// -----------------------------------------------------------------------


class XMLNodeList {

	public:

		// constructors

        	XMLNodeList     ( XMLNode * pNode );                 			// constructor
        	XMLNodeList     ( const XMLNodeList& pNodeListSrc );   		    // copy constructor

		// destructors

        	~XMLNodeList    ( void );                                       // destructor

		// modifiers

			XMLNode* 	AppendSibling       ( XMLNode* pNode );
			bool        MoveToNode          ( XMLNode* pNode );

		// selectors

		// iterators

		// friends

	protected:

	private:

        XMLNode* 	vFirstNode;
        XMLNode*    vLastNode;    
};

#include	"xmltree.hxx"

#endif // XMLTREE_HPP

// End-of-file

