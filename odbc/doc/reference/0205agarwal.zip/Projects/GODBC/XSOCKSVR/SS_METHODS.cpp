// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

// ---------------------------------------------------------------------------------
//
// File:    SS_METHODS.CPP
//
// Author:  Vikash K Agarwal
//
// Notes:   This file contains the actual methods which are called
//          from the dummy client XSOCKCLI or from the ODBC driver.
//
//          It provides the basic functions and their response
//          in hard-coded form. Assuming that there are 2 databases,
//          2 users and 2 tables. All SELECT queries will generate
//          them same five row response which contains columns of
//          different types. 
//
//          Using the ODBCDRV1 provided, and this dummy server
//          you will be able to get data into MS Query, Word,
//          Excel and even SQL server using DTS.
//
//          To explain once more, the ODBC client calls a method
//          say SQLExecDirect. The client passes it to Driver 
//          Manager (ODBC32.LIB). The driver manager forwards the call
//          to our driver ODBCDRV1.DLL. The DLL packages the call as shown
//          in sample below and transfers it to server over socket.
//          The method name is checked and accordingly the corresponding
//          function is called, which uses the helper functions
//          and prepares the SOAP/XML response and posts back to the socket.
//          This is an example of using SOAP over sockets for RPC
//          and is capable for being used in local/LAN and WAN
//          environments. 
//
//          A request is typically of three types
//          1. Connect   
//          2. Catalog functions - for table names, keys, columsn etc
//          3. Execute statements - for SELECT statements etc
//
//          A request will consist of method name and associated
//          parameters like Connect would required UID/PWD.
//          Similarly Execute would require statement etc
//			All requests have a method name which is further divided
//			into 2 parts STMT and VARIABLES. STMT can also be treated
//			as variable but i have specifically 
//			kept it separate. VARIABLES contain the other params
//			required for that method.
//
//          A response has the method name containing the resulttype
//          as an attribute. The most common resulttype is a resultset.
//          The method contains RESULTDESC and RESULTDATA. The RESULTDESC
//          contains meta data about the rowset put inside RESULTDATA. This
//          metadata is fixed to NAME, ALIAS, TYPE, LENGTH, PRECISION, 
//			SCALE, NULLABLE. RESULTDATA contains rows as ROW which in 
//			turn contain COLS
//
//          Request samples:
//                      ( a typical connect request )
//                      <ENVELOPE><HEADER></HEADER><BODY> 
//                      <SQLConnect> 
//						<VARIABLES>
//                      <UID>user</UID> 
//                      <PWD>user</PWD> 
//						</VARIABLES>
//                      </SQLConnect>
//                      </BODY></ENVELOPE>
//
//                      ( a typical request to collect databases/tables )
//                      <ENVELOPE><HEADER></HEADER><BODY>
//                      <SQLTables>
//						<VARIABLES>
//                      <CATALOG>%</CATALOG>
//                      <SCHEMA>user</SCHEMA>
//                      <TABLE>%</TABLE>
//                      <TABLETYPE></TABLETYPE>
//						</VARIABLES>
//                      </SQLTables>
//                      </BODY></ENVELOPE>
//
//                      ( a typical request to execute a query )
//                      <ENVELOPE><HEADER></HEADER><BODY>
//                      <SQLExecute>
//                      <STMT>SELECT * FROM employee</STMT>
//						<VARIABLES></VARIABLES>
//                      </SQLExecute>
//                      </BODY></ENVELOPE>
//
//          Response samples
//                      ( a typical SQLConnect response )
//                      <ENVELOPE><HEADER></HEADER><BODY> 
//                      <SQLConnectResponse ResultType=Bool ResultValue=1> 
//                      </SQLConnectResponse>
//                      </BODY></ENVELOPE>
//
//                      ( a typical SQLTables/SQLExecute response )
//                      <ENVELOPE><HEADER></HEADER><BODY> 
//                      <SQLTablesResponse ResultType=Resultset> 
//                      <RESULTDESC>
//                          <ROWDESC>
//                              <COL>
//                              </COL>
//                              ...
//                          </ROWDESC>
//                      </RESULTDESC>
//                      <RESULTDATA>
//                          <ROW>
//                              <_1>
//                              </_1>
//                              <_2>
//                              </_2>
//                              ...
//                          </ROW>    
//                          ...    
//                          </ROWDDESC>
//                      </RESULTDESC>
//                      </SQLTablesResponse>
//                      </BODY></ENVELOPE>
// ----------------------------------------------------------------------------------

// ------------------------ include files -----------------------------
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#include <xmllex.hpp>
#include <xmlparse.hpp>

// ----------------- SOAP function prototypes from SS_SOAP.cpp ----------------
int             SOAPChildElemCount          ( XMLNode* pNode );
const char*     SOAPGetElemText             ( XMLNode* pNode );
XMLNode*        SOAPGetChildElemX           ( XMLNode* pNode, int pIndex );
XMLNode*        SOAPFindElem                ( XMLNode* pNode, char* pElemName );
XMLNode*        SOAPLocateHEAD              ( XMLNode* pNode );
XMLNode*        SOAPLocateBODY              ( XMLNode* pNode );
bool            SOAPAddElemToNode           ( XMLNode* pNode, char* pElemName, char* pElemValue, XMLNode** pNewNode );
bool            SOAPAddMethodToResp         ( XMLNode* pNodeRespBody, const char* pMethodName, XMLNode** pNewNode );
bool            SOAPAddNodeToMethod         ( XMLNode* pNodeMethod, short pParamType, char* pParamName, void* pParamValue, XMLNode** pNewNode );
bool            SOAPCheckReq                ( XMLNode* pNode, XMLNode** pMethod, XMLNode** pStmt, XMLNode** pVars );
bool            SOAPCreateFaultResp         ( XMLNode* pMethod, XMLNode** pResp );
bool            SOAPCreateResp              ( XMLNode** pNodeResp, XMLNode** pNodeRespHead, XMLNode** pNodeRespBody, XMLNode** pNodeMethod, const char* pMethodName );
bool            SOAPDeleteResp              ( XMLNode* pNode );

// ----------------------- local function prototypes --------------------------
bool            AddXMLRowDesc               ( XMLNode* pNode, struct RowDesc* pRowDesc );
bool            AddXMLRow                   ( XMLNode* pNode, char pColNames[][4], char pColValues[][32] );

bool            SQLConnect                  ( XMLNode* pMethodReq, XMLNode* nRespMethod, XMLNode* pResp );
bool            SQLTables                   ( XMLNode* pMethodReq, XMLNode* nRespMethod, XMLNode* pResp );
bool            SQLColumns                  ( XMLNode* pMethodReq, XMLNode* nRespMethod, XMLNode* pResp );
bool            SQLSpecialColumns           ( XMLNode* pMethodReq, XMLNode* nRespMethod, XMLNode* pResp );
bool            SQLGetTypeInfo              ( XMLNode* pMethodReq, XMLNode* nRespMethod, XMLNode* pResp );
bool            SQLExecute                  ( XMLNode* pMethodReq, XMLNode* nRespMethod, XMLNode* pResp );

bool            CreateMethodResponse        ( XMLNode* pMethod, XMLNode** pResp );


// ----------------- generic struct for column definition ---------------------
struct RowDesc {
    char    name[64];
    char    alias[64];
    char    type[32];
    char    length[11];
    char    precision[3];
    char    scale[3];
    char    nullable[2];
};

            // HELPER FUNCTIONS

// --------------------------------------------------------------------
// to add and XML row desc element
// --------------------------------------------------------------------

bool AddXMLRowDesc ( XMLNode* pNode, struct RowDesc* pRowDesc )
{
    // note
    // receives RESULTDESC
    // adds ROWDESC and then the fixed info for each COL.
	// All the details for each col is encapsulated inside pRowDesc
	// essentially creates the metadata for the resultset

    short		i = 0;
    XMLNode*    r;
    XMLNode*    c;

    // precaution
    if ( pNode == NULL || pRowDesc == NULL )
        return false;

    // add the rowdesc element
    SOAPAddElemToNode ( pNode, "ROWDESC", NULL, &r );

    // loop with arbitary limit as precaution
    while ( pRowDesc[i].name[0] != 0 && i < 32 ) {

        // col
        SOAPAddElemToNode ( r, "COL", NULL, &c );

            // COL ATTRIBUTES

        // name
        SOAPAddElemToNode ( c, "NAME", pRowDesc[i].name, NULL );

        // alias
        SOAPAddElemToNode ( c, "ALIAS", pRowDesc[i].alias, NULL );

        // type
        SOAPAddElemToNode ( c, "TYPE", pRowDesc[i].type, NULL );

        // length
        SOAPAddElemToNode ( c, "LENGTH", pRowDesc[i].length, NULL );

        // precision
        SOAPAddElemToNode ( c, "PRECISION", pRowDesc[i].precision, NULL );

        // scale
        SOAPAddElemToNode ( c, "SCALE", pRowDesc[i].scale, NULL );

        // nullable
        SOAPAddElemToNode ( c, "NULLABLE", pRowDesc[i].nullable, NULL );

        // next col
        i ++;
    }

    return true;
}


// -------------------------------------------------------------------
// to add and XML row data element with specified col names and values
// -------------------------------------------------------------------

bool AddXMLRow ( XMLNode* pNode, char pColNames[][4], char pColValues[][32] )
{
    // note
    // receives RESULTDATA
    // adds ROW and then the COLs and values.
	// the name of col tags r irrelevant, the order should be same as
	// described by RESULTDATA. The name of the column is picked from
	// RESULTDATA just like any other details.
	// say <RESULTDESC><ROWDESC><COL><NAME>author_name</NAME>...</COL></ROWDESC></RESULTDESC>
	// maps <RESULTDATA><ROW><C1>Mr. XYZ</C1></ROW></RESULTDATA>
	// here the tag name C1 is irrelevant

    short       i = 0;
    XMLNode*    n;

    // precaution
    if ( pColNames == NULL || pColValues == NULL || pNode == NULL )
        return false;

    // add the row element
    SOAPAddElemToNode ( pNode, "ROW", NULL, &n );

    // loop with arbitary limit as precaution
    while ( pColNames[i] && pColNames[i][0] && i < 64 ) {

        // create the column node
        SOAPAddElemToNode ( n, pColNames[i], pColValues[i], NULL );

        // next col
        ++ i;
    }

    return true;
}

            // ODBC FUNCTIONS

// -----------------------------------------------------------------------
// to validate a connection request
// -----------------------------------------------------------------------

bool SQLConnect ( XMLNode* pMethodReq, XMLNode* nRespMethod, XMLNode* pResp )
{
    // Note
    // connect request originates in form of SQLConnect, SQLDriverConnect, SQLBrowseConnect

    // asummes that everything is well, when u use your actual DBMS
    // the user name and password can be checked and a unique connection
    // ID can also be returned. For the sake of simplicity we would 
    // implement everything in stateless fashion so this is treated as a
	// dummy connection and every request is fresh connection

    // add the result type as an attribute
    nRespMethod->AppendChildNodeBeforeX ( XMLNode::CreateAttribute ( "ResultType", "Bool" ), NULL );
	nRespMethod->AppendChildNodeBeforeX ( XMLNode::CreateAttribute ( "ResultValue", "1" ), NULL );

    // add any other info required by DBMS
    SOAPAddElemToNode ( nRespMethod, "ConnID", "999", NULL );

    return true;   
}


// -----------------------------------------------------------------------
// to execute SQLTables to get list of database, user, tables
// -----------------------------------------------------------------------

bool SQLTables ( XMLNode* pMethodReq, XMLNode* nRespMethod, XMLNode* pResp )
{
    char colnames[][4] = { {"_1"}, {"_2"}, {"_3"}, {"_4"}, {"_5"}, {""} };
    char colvalues[][32] = { {"DB1"}, {"user1"}, {"EmployeeTable1"}, {"TABLE"}, {"NULL"} };

    struct RowDesc rd[] = {
        {"TABLE_CAT",   "TABLE_CAT",    "VARCHAR",  "32",   "", "", "Y"},
        {"TABLE_SCHEM", "TABLE_SCHEM",  "VARCHAR",  "32",   "", "", "Y"},
        {"TABLE_NAME",  "TABLE_NAME",   "VARCHAR",  "32",   "", "", "Y"},
        {"TABLE_TYPE",  "TABLE_TYPE",   "VARCHAR",  "32",   "", "", "Y"},
        {"REMARKS",     "REMARKS",      "VARCHAR",  "32",   "", "", "Y"},
        {"","","","","","",""}
    };

    XMLNode*    n;              

        // RESULTTYPE

    // add the result type as an attribute
    nRespMethod->AppendChildNodeBeforeX ( XMLNode::CreateAttribute ( "ResultType", "ResultSet" ), NULL );

        // RESULTDESC

    // create the RESULTDESC
    SOAPAddElemToNode ( nRespMethod, "RESULTDESC", NULL, &n );

        // RESULTDESC.ROWDESC

    AddXMLRowDesc ( n, rd );

        // RESULTDATA

    SOAPAddElemToNode ( nRespMethod, "RESULTDATA", NULL, &n );

        // RESULTDATA.ROW

    // add the first row
    AddXMLRow ( n, colnames, colvalues );

    // prepare another row
    strcpy ( colvalues[0], "DB2" );
    strcpy ( colvalues[1], "user2" );
    strcpy ( colvalues[2], "EmployeeTable2" );

        // RESULTDATA.ROW

    // add the second row
    AddXMLRow ( n, colnames, colvalues );

    return true;
}

// -----------------------------------------------------------------------
// to execute SQLColumns to get list of columns
// -----------------------------------------------------------------------

bool SQLColumns ( XMLNode* pMethodReq, XMLNode* nRespMethod, XMLNode* pResp )
{
    // note
    // although i have used _1 _2 and so on for the col names, this is
    // not a requiremet. In fact any thing will do since the driver will
    // match the col with the position in ROWDESC. It should be a valid
    // XML tag
    // the function returns that there r 8 cols in the resultset
    // and each is of a different type. 18 cols are required to
    // describe the col itself.

    char colnames[][4] = {     {"_1"}, {"_2"}, {"_3"}, {"_4"}, {"_5"}, 
                                {"_6"}, {"_7"}, {"_8"}, {"_9"}, {"_10"}, 
                                {"_11"}, {"_12"}, {"_13"}, {"_14"}, {"_15"}, 
                                {"_16"}, {"_17"}, {"_18"}, {""} 
                        };

    char colvalues[][32] = {    {"DB1"}, {"user1"}, {"EmployeeTable1"}, {"COL1"}, 
                                {"12"}, {"VARCHAR"}, {"32"}, {"32"}, {"0"},
                                {"NULL"}, {"N"}, {"NULL"}, {"DEF"}, {"12"},
                                {"NULL"}, {"NULL"}, {"1"}, {"DEF"}, {"NULL"},
                                {""}
                            };

    struct RowDesc rd[] = {
        {"TABLE_CAT",           "TABLE_CAT",        "VARCHAR",      "32",   "", "", "Y"},
        {"TABLE_SCHEM",         "TABLE_SCHEM",      "VARCHAR",      "32",   "", "", "Y"},
        {"TABLE_NAME",          "TABLE_NAME",       "VARCHAR",      "32",   "", "", "N"},
        {"COLUMN_NAME",         "COLUMN_NAME",      "VARCHAR",      "32",   "", "", "N"},
        {"DATATYPE",            "DATATYPE",         "I2",           "",     "5", "", "N"},
        {"TYPENAME",            "TYPENAME",         "VARCHAR",      "",     "", "", "Y"},
        {"COLUMNSIZE",          "COLUMNSIZE",       "I4",           "",     "10", "", "Y"},
        {"BUFFER_LENGTH",       "BUFFER_LENGTH",    "I4",           "32",   "10", "", "Y"},
        {"DECIMAL_DIGITS",      "DECIMAL_DIGITS",   "I2",           "32",   "5", "", "Y"},
        {"NUM_PREC_RADIX",      "NUM_PREC_RADIX",   "I2",           "32",   "5", "", "Y"},
        {"NULLABLE",            "NULLABLE",         "I2",           "32",   "5", "", "N"},
        {"REMARKS",             "REMARKS",          "VARCHAR",      "32",   "", "", "Y"},
        {"COLUMN_DEF",          "COLUMN_DEF",       "CHAR",         "32",   "", "", "Y"},
        {"SQL_DATA_TYPE",       "SQL_DATA_TYPE",    "I2",           "",     "5", "", "N"},
        {"SQL_DATETIME_SUB",    "SQL_DATETIME_SUB", "I2",           "",     "5", "", "Y"},
        {"CHAR_OCTET_LENGTH",   "CHAR_OCTET_LENGTH","I4",           "",     "10", "", "Y"},
        {"ORDINAL_POSITION",    "ORDINAL_POSITION", "I2",           "",     "5", "", "N"},
        {"IS_NULLABLE",         "IS_NULLABLE",      "VARCHAR",      "32",   "", "", "Y"},
        {"","","","","","",""}
    };

    XMLNode*    n;              


        // RESULTTYPE

    // add the result type
    nRespMethod->AppendChildNodeBeforeX ( XMLNode::CreateAttribute ( "ResultType", "ResultSet" ), NULL );

        // RESULTDESC

    // create the RESULTDESC
    SOAPAddElemToNode ( nRespMethod, "RESULTDESC", NULL, &n );


        // RESULTDESC.ROWDESC

    AddXMLRowDesc ( n, rd );

        // RESULTDATA

    SOAPAddElemToNode ( nRespMethod, "RESULTDATA", NULL, &n );

        // RESULTDATA.ROW

    // first row
    AddXMLRow ( n, colnames, colvalues );

    // more rows, just by modifying the required values

    strcpy ( colvalues[3], "COL2" );
    strcpy ( colvalues[4], "12" );
    strcpy ( colvalues[5], "VARCHAR" );
    AddXMLRow ( n, colnames, colvalues );

    strcpy ( colvalues[3], "COL3" );
    strcpy ( colvalues[4], "1" );
    strcpy ( colvalues[5], "CHAR" );
    AddXMLRow ( n, colnames, colvalues );

    strcpy ( colvalues[3], "COL4" );
    strcpy ( colvalues[4], "5" );
    strcpy ( colvalues[5], "I2" );
    AddXMLRow ( n, colnames, colvalues );

    strcpy ( colvalues[3], "COL5" );
    strcpy ( colvalues[4], "4" );
    strcpy ( colvalues[5], "I4" );
    AddXMLRow ( n, colnames, colvalues );

    strcpy ( colvalues[3], "COL6" );
    strcpy ( colvalues[4], "6" );
    strcpy ( colvalues[5], "FLOAT" );
    AddXMLRow ( n, colnames, colvalues );

    strcpy ( colvalues[3], "COL7" );
    strcpy ( colvalues[4], "91" );
    strcpy ( colvalues[5], "DATE" );
    AddXMLRow ( n, colnames, colvalues );

    strcpy ( colvalues[3], "COL8" );
    strcpy ( colvalues[4], "0" );               // still kept as an unknown data type
    strcpy ( colvalues[5], "BOOL" );
    AddXMLRow ( n, colnames, colvalues );

    return true;
}

// -----------------------------------------------------------------------
// to execute SQLSpecialColumns to get list of p-key columns or updateable cols
// -----------------------------------------------------------------------

bool SQLSpecialColumns  ( XMLNode* pMethodReq, XMLNode* nRespMethod, XMLNode* pResp )
{
    // note
    // returns the first col returned by SQLColumns as the col
    //  which s unique

    char colnames[][4] = {     {"_1"}, {"_2"}, {"_3"}, {"_4"}, {"_5"}, 
                                {"_6"}, {"_7"}, {"_8"}, {""} 
                        };

    char colvalues[][32] = {    {"1"}, {"COL1"}, {"12"}, {"varchar"}, 
                                {"32"}, {"32"}, {"0"}, {"0"},
                                {""}
                            };

    struct RowDesc rd[] = {
        {"SCOPE",               "SCOPE",            "I2",           "",     "5",  "", "Y"},
        {"COLUMN_NAME",         "COLUMN_NAME",      "VARCHAR",      "32",   "",   "", "N"},
        {"DATA_TYPE",           "DATA_TYPE",        "I2",           "",     "5",  "", "N"},
        {"TYPE_NAME",           "TYPE_NAME",        "VARCHAR",      "32",   "",   "", "N"},
        {"COLUMN_SIZE",         "COLUMN_SIZE",      "I4",           "10",   "10", "", "Y"},
        {"BUFFER_LENGTH",       "BUFFER_LENGTH",    "I4",           "10",   "10", "", "Y"},
        {"DECIMAL_DIGITS",      "DECIMAL_DIGITS",   "I2",           "",     "5", "", "Y"},
        {"PSEUDO_COLUMN",       "PSEUDO_COLUMN",    "I2",           "",   "5", "", "Y"},
        {"","","","","","",""}
    };

    XMLNode*    n;              


        // RESULTTYPE

    // add the result type
    nRespMethod->AppendChildNodeBeforeX ( XMLNode::CreateAttribute ( "ResultType", "ResultSet" ), NULL );

        // RESULTDESC

    // create the RESULTDESC
    SOAPAddElemToNode ( nRespMethod, "RESULTDESC", NULL, &n );


        // RESULTDESC.ROWDESC

    AddXMLRowDesc ( n, rd );
    
        // RESULTDATA

    SOAPAddElemToNode ( nRespMethod, "RESULTDATA", NULL, &n );

        // RESULTDATA.ROW

    // first row
    AddXMLRow ( n, colnames, colvalues );

    return true;
}

// -----------------------------------------------------------------------
// to execute SQLGetTypeInfo and get type information
// -----------------------------------------------------------------------

bool SQLGetTypeInfo ( XMLNode* pMethodReq, XMLNode* nRespMethod, XMLNode* pResp )
{
    // note
    // this is an important function, since it allows the client to
    // determine the name and nature of the data types supported by
    // your server. Each data type supported by your server has to be
    // described where the crucial information includes its name
    // and the corresponding SQL data type. Say varchar is 12, 
    // 16-bit int 5 and so on.

    struct RowDesc rdesc[] = {
        {"TYPE_NAME",           "", "VARCHAR",     "32",   "", "","N"},
        {"DATA_TYPE",           "", "I2",          "",     "5", "","N"},
        {"COLUMN_SIZE",         "", "I4",          "",     "10", "","Y"},
        {"LITERAL_PREFIX",      "", "VARCHAR",     "32",   "", "","Y"},
        {"LITERAL_SUFFIX",      "", "VARCHAR",     "32",   "", "","Y"},
        {"CREATE_PARAMS",       "", "VARCHAR",     "32",   "", "","Y"},
        {"NULLABLE",            "", "I2",          "",     "5", "","N"},
        {"CASE_SENSITIVE",      "", "I2",          "",     "5", "","N"},
        {"SEARCHABLE",          "", "I2",          "",     "5", "","N"},
        {"UNSIGNED_ATTRIBUTE",  "", "I2",          "",     "5", "","Y"},
        {"FIXED_PREC_SCALE",    "", "I2",          "",     "5", "","N"},
        {"AUTO_UNIQUE_VALUE",   "", "I2",          "",     "5", "","Y"},
        {"LOCAL_TYPE_NAME",     "", "VARCHAR",     "32",   "", "","Y"},
        {"MINIMUM_SCALE",       "", "I2",          "",     "5", "","Y"},
        {"MAXIMUM_SCALE",       "", "I2",          "",     "5", "","Y"},
        {"SQL_DATA_TYPE"        "", "I2",          "",     "5", "","N"},
        {"SQL_DATETIME_SUB",    "", "I2",          "",     "5", "","Y"},
        {"NUM_PREC_RADIX",      "", "I4",          "",     "10", "","Y"},
        {"INTERVAL_PRECISION",  "", "I2",          "",     "5", "","Y"},
        {"","","","", "", "", ""}
    };

    char colnames[][4] = {    
        {"_1"}, {"_2"}, {"_3"}, {"_4"}, {"_5"}, 
        {"_6"}, {"_7"}, {"_8"}, {"_9"}, {"_10"}, 
        {"_11"}, {"_12"}, {"_13"}, {"_14"}, {"_15"}, 
        {"_16"}, {"_17"}, {"_18"}, {"_19"}, {""}
    };

    struct RowData {
        char colvalues[20][32];
    };

    struct RowData rdata[] = {
        {  
            {
                {"char"}, {"1"}, {"255"}, {"'"}, 
                {"'"}, {"length"}, {"1"}, {"0"}, {"3"},
                {"NULL"}, {"0"}, {"NULL"}, {"char"}, {"NULL"},
                {"NULL"}, {"1"}, {"NULL"}, {"NULL"}, {"NULL"},
                {""}
            }
        },
        {
            {
                {"varchar"}, {"12"}, {"32765"}, {"'"}, 
                {"'"}, {"length"}, {"1"}, {"0"}, {"3"},
                {"NULL"}, {"0"}, {"NULL"}, {"varchar"}, {"NULL"},
                {"NULL"}, {"12"}, {"NULL"}, {"NULL"}, {"NULL"},
                {""}
            }
        },
        {
            {
                {"i2"}, {"5"}, {"5"}, {"NULL"}, 
                {"NULL"}, {"NULL"}, {"1"}, {"0"}, {"3"},
                {"0"}, {"0"}, {"NULL"}, {"i2"}, {"0"},
                {"5"}, {"5"}, {"NULL"}, {"NULL"}, {"NULL"},
                {""}
            }
        },
        {
            {
                {"i4"}, {"4"}, {"5"}, {"NULL"}, 
                {"NULL"}, {"NULL"}, {"1"}, {"0"}, {"3"},
                {"0"}, {"0"}, {"NULL"}, {"i4"}, {"0"},
                {"5"}, {"4"}, {"NULL"}, {"NULL"}, {"NULL"},
                {""}
            }
        },
        {
            {
                {"float"}, {"6"}, {"10"}, {"NULL"}, 
                {"NULL"}, {"precision,scale"}, {"1"}, {"0"}, {"3"},
                {"0"}, {"0"}, {"NULL"}, {"float"}, {"NULL"},
                {"NULL"}, {"float"}, {"NULL"}, {"NULL"}, {"NULL"},
                {""}
            }
        },
        {
            {
                {"date"}, {"91"}, {"32"}, {"NULL"}, 
                {"NULL"}, {"NULL"}, {"1"}, {"0"}, {"3"},
                {"NULL"}, {"0"}, {"NULL"}, {"date"}, {"NULL"},
                {"NULL"}, {"91"}, {"NULL"}, {"NULL"}, {"NULL"},
                {""}
            }
        },
        {
            {
                {"bool"}, {"-7"}, {"1"}, {"NULL"}, 
                {"NULL"}, {"NULL"}, {"1"}, {"0"}, {"3"},
                {"1"}, {"0"}, {"NULL"}, {"bool"}, {"NULL"},
                {"NULL"}, {"-7"}, {"NULL"}, {"NULL"}, {"NULL"},
                {""}
            }
         }
    };


    int         x;
    XMLNode*    n;              


        // RESULTTYPE

    // add the result type
    nRespMethod->AppendChildNodeBeforeX ( XMLNode::CreateAttribute ( "ResultType", "ResultSet" ), NULL );

        // RESULTDESC

    // create the RESULTDESC
    SOAPAddElemToNode ( nRespMethod, "RESULTDESC", NULL, &n );


        // RESULTDESC.ROWDESC

    AddXMLRowDesc ( n, rdesc );

        // RESULTDATA

    SOAPAddElemToNode ( nRespMethod, "RESULTDATA", NULL, &n );

        // RESULTDATA.ROW

    // add the eight rows one each for a  data type
    for ( x = 0; x < 7; x ++ )
        AddXMLRow ( n, colnames, rdata[x].colvalues );

    return true;
}

// -------------------------------------------------------------------
// to execute a SQL statement
// -------------------------------------------------------------------

bool SQLExecute ( XMLNode* pMethodReq, XMLNode* nRespMethod, XMLNode* pResp )
{
    // note
    // matching with the information returned by SQLColumns
    // this function returns 5 rows of eight cols each.

    struct RowDesc rd[] = {
        {"COL1",    "COL1", "I2",       "2",    "5",    "", "Y"},
        {"COL2",    "COL2", "VARCHAR",  "32",   "",     "", "Y"},
        {"COL3",    "COL3", "CHAR",     "32",   "",     "", "Y"},
        {"COL4",    "COL4", "I2",       "2",    "5",    "", "Y"},
        {"COL5",    "COL5", "I4",       "4",    "10",   "", "Y"},
        {"COL6",    "COL6", "FLOAT",    "4",    "10",   "", "Y"},
        {"COL7",    "COL7", "DATE",     "25",   "",     "", "Y"},
        {"COL8",    "COL8", "BOOL",     "1",    "",     "", "Y"},
        {"","","",""}
    };

    char colnames[][4] = { {"_1"}, {"_2"}, {"_3"}, {"_4"}, {"_5"}, {"_6"}, {"_7"}, {"_8"},  {""} };
    char colvalues[][32] = { {"1"}, {"Varchar"}, {"char"}, {"2"}, {"4"}, {"2.4"}, {"20001223"}, {"true"}, {""} };

    short        i;
    XMLNode*    n;              

        // RESULTTYPE

    // add the result type
    nRespMethod->AppendChildNodeBeforeX ( XMLNode::CreateAttribute ( "ResultType", "ResultSet" ), NULL );

        // RESULTDESC

    // create the RESULTDESC
    SOAPAddElemToNode ( nRespMethod, "RESULTDESC", NULL, &n );

        // RESULTDESC.ROWDESC

    AddXMLRowDesc ( n, rd );

        // RESULTDATA

    SOAPAddElemToNode ( nRespMethod, "RESULTDATA", NULL, &n );

        // RESULTDATA.ROW

    for ( i = 0; i < 5; i ++ ) {

        // first col is a serial id, so increment it
        memset ( colvalues[0], 0, 32 );
        sprintf ( colvalues[0], "%d", i+1 );

        // add the row to result
        AddXMLRow ( n, colnames, colvalues );
    }

    return true;
}

// -----------------------------------------------------------------------
// main function to check the method and use the appropriate function
// -----------------------------------------------------------------------

bool CreateMethodResponse ( XMLNode* pMethod, XMLNode** pResp )
{
    XMLNode* nRespMethod;

    // caller safe
    if ( pResp )        *pResp = 0;

    // create a generic SOAP response frame
    if ( SOAPCreateResp ( pResp, NULL, NULL, &nRespMethod, pMethod->GetNodeName()) != true )
        return false;

    // branch as per methodname

    if ( stricmp ( pMethod->GetNodeName(), "SQLConnect" ) == 0 )
        return SQLConnect ( pMethod, nRespMethod, *pResp );

    else if ( stricmp ( pMethod->GetNodeName(), "SQLTables" ) == 0 )
        return SQLTables ( pMethod, nRespMethod, *pResp );

    else if ( stricmp ( pMethod->GetNodeName(), "SQLColumns" ) == 0 )
        return SQLColumns ( pMethod, nRespMethod, *pResp );

    else if ( stricmp ( pMethod->GetNodeName(), "SQLSpecialColumns" ) == 0 )
        return SQLSpecialColumns ( pMethod, nRespMethod, *pResp );

    else if ( stricmp ( pMethod->GetNodeName(), "SQLGetTypeInfo" ) == 0 )
        return SQLGetTypeInfo ( pMethod, nRespMethod, *pResp );

    else if ( stricmp ( pMethod->GetNodeName(), "SQLExecStmt" ) == 0 || stricmp ( pMethod->GetNodeName(), "SQLExecute" ) == 0 || stricmp ( pMethod->GetNodeName(), "SQLExecDirect" ) == 0 || stricmp ( pMethod->GetNodeName(), "SQLPrepare" ) == 0)
        return SQLExecute ( pMethod, nRespMethod, *pResp );

    else {
        printf ( "Invalid method: %s", pMethod->GetNodeName());
        return false;
    }
}

