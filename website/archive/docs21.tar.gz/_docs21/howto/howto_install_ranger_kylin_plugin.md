---
layout: docs21
title:  The Ranger Kylin Plugin Installation Guide
categories: howto
permalink: /docs21/howto/howto_install_ranger_kylin_plugin.html
---

Please refer to [https://cwiki.apache.org/confluence/display/RANGER/Kylin+Plugin](https://cwiki.apache.org/confluence/display/RANGER/Kylin+Plugin).