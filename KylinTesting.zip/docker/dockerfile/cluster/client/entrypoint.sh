#!/bin/bash

/opt/entrypoint/hadoop/entrypoint.sh
/opt/entrypoint/hive/entrypoint.sh
/opt/entrypoint/hbase/entrypoint.sh
#/opt/entrypoint/zookeeper/entrypoint.sh
#/opt/entrypoint/kafka/entrypoint.sh
