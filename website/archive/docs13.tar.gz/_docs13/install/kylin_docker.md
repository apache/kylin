---
layout: docs
title:  "Run Kylin with Docker"
categories: install
permalink: /docs/install/kylin_docker.html
version: v0.6
since: v0.6
---

Apache Kylin runs as a client of Hadoop cluster, so it is reasonable to run within a Docker container; please check [this project](https://github.com/Kyligence/kylin-docker/) on github.
  
