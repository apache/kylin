---
layout: docs23-cn
title:  "用 Docker 运行 Kylin"
categories: install
permalink: /cn/docs23/install/kylin_docker.html
version: v1.5.3
since: v1.5.2
---

Apache Kylin 作为一个 Hadoop 集群的客户端运行, 因此运行在 Docker 容器中是合理的; 请查看 github [this project](https://github.com/Kyligence/kylin-docker/).
