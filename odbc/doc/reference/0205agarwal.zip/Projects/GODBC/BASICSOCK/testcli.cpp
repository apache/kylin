// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

// ---------------------------------------------------------------------------------
//
// File:    TESTCLI.CPP
//
// Notes:   To demonstrate the basic functions required for connecting
//			using sockets. Essentially demonstrates the code snippet
//			described in the article. 
//			Connects to the test server TESTSVR and sends and receives
//			a hello, that is all.
//			It is not a full fledged client and is only present here
//			for beginning socket communication. 
//			Our driver and the other sample (XSOCKCLI) uses TSockClient
//			class implemented in SOCK_CLI.CPP
//			The TESTSVR exe must be running for this client to work
// ----------------------------------------------------------------------------------


#include <stdio.h>
#include <winsock.h>

void main ( void )
{
    int				status;					// status or return values
    SOCKET			sckt;					// socket handle like file handle
	WSADATA			wsadata;				// winsock requirement for startup
	SOCKADDR_IN		address;				// structure for IP, port etc.
	char			buf[512];				// buffer to recv response

    // winsock initialization, specify the version required
    status = WSAStartup ( MAKEWORD( 1, 1 ), &wsadata );

	// create a socket, no address associated as yet
    sckt = socket ( AF_INET, SOCK_STREAM, 0 );  

	// address of server to communicate with
	address.sin_addr.s_addr = inet_addr ( "127.0.0.1" );
    address.sin_family		=  AF_INET;			// address family   
    address.sin_port		=  htons ( 9999 );  // port number

	// connect to server analogous to opening a file
    status = connect ( sckt, ( struct sockaddr* )&address, sizeof(address));

	// check
	if ( status != 0 ) {
		printf ( "Error -- cannot connect, probably TESTSVR not running\n" );
		exit ( 0 );
	}


	// send a hello to server/listener
    status = send ( sckt, "Hello server", strlen ( "Hello server" ), 0 );

	// recv response from server
    status = recv ( sckt, buf, 512, 0 );

	// initiate a shutdown for both send and recv
	status = shutdown ( sckt, 0x02 );                 

	// close the socket handle
	status = closesocket( sckt );

	// winsock finalization
	WSACleanup ();

	// complete
	printf ( "Done.\n" );
}
