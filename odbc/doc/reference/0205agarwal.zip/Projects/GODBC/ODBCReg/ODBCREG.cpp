// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

// ----------------------------------------------------------------------------
//
// File:        ODBCREG.cpp
//
// Purpose:     To register the specified ODBC driver so that the system
//				can recognize it. Also allows you to unregister the driver
//
// Author:      Vikash K Agarwal
//
// Notes:       To register u will need to specify three things
//				1. Driver Name example General ODBC driver
//				2. DLL name example ODBCDRV0.DLL
//				3. DLL path example C:\TEMP
//				In case u do not specify any of these the defaults r used.
//
//				To install a driver 
//				ODBCREG /i DriverName DLLName DLLPath
//				
//				To uninstall a driver 
//				ODBCREG /u DriverName
//
//				To get the full syntax with example
//				ODBCREG
// ----------------------------------------------------------------------------

// --------------------------- include files ----------------------------------
#include <stdio.h> 
#include <conio.h>
#include <windows.h> 

#include <odbcinst.h>								// installer functions

// ---------------------------- default driver name ---------------------------
#define DRIVER_NAME         "General ODBC Driver 0"

// ------------------------------ default DLL Name ----------------------------
#define DLL_NAME            "ODBCDRV0.DLL"

// -----------------------------------------------------------------------
// register the driver & DLL to specified path
// -----------------------------------------------------------------------
 
void ODBCRegDriver ( char* pDriverName, char* pDLLName, char* pPath )
{
    BOOL				f;
    WORD				x;
    DWORD				y;
    char				sDesc[1024];						// arbitary length
    char				szOutPath[1024];					// arbitary length
	WIN32_FIND_DATA		FindFileData;		

			// check if driver exists as a precaution --- this part can be eliminated
    
	// create full path name
	strcpy ( szOutPath, pPath );
    if ( szOutPath[strlen ( szOutPath) -1] != '\\' ) strcat ( szOutPath, "\\" );
    strcat ( szOutPath, pDLLName );

    // check if driver DLL exists or not    
    if ( FindFirstFile ( szOutPath, &FindFileData ) == INVALID_HANDLE_VALUE ) {

        printf ( "Error: Could not locate driver DLL %s\n", szOutPath );
        return;
    }
	
		//////////////


	// string format for driver description
	//    driver-desc\0Driver=driver-DLL-filename\0[Setup=setup-DLL-filename\0]
    //    [driver-attr-keyword1=value1\0][driver-attr-keyword2=value2\0]...\0
	//
	// example
	//	  General ODBC Driver\0Driver=ODBCDRV0.DLL\0Setup=ODBCDRV0.DLL

	// local initializations
	memset ( szOutPath, 0, 1024 );

    // prepare in string as per above shown format
    memset ( sDesc, 0, 1024 );
    strcpy ( sDesc, pDriverName );
    sprintf ( sDesc + strlen ( sDesc ) + 1, "Driver=%s", pDLLName );

    // install the driver by making registry changes
    f = SQLInstallDriverEx ( sDesc, pPath, szOutPath, 1024, &x, ODBC_INSTALL_COMPLETE, &y );

	// success
    if( f == TRUE ) {
        printf ( "%s installed/registered successfully\n", pDriverName );
        return;
    }
	else {
		printf ( "Registration failed, error no.: %d\n", SQLInstallerError ( 1, &y, szOutPath, 512, &x ));
		printf ( "Error details: %s\n", szOutPath );
	}
}

// -----------------------------------------------------------------------
// un-register the driver 
// -----------------------------------------------------------------------

void ODBCUnRegDriver ( char* pDriverName )
{
	// this will unregister as many number of times, as many times
	// the driver was installed as shown by UsageCount registry key

    BOOL    f;
    WORD    c; 
    WORD    x;
    DWORD   y;
    char    szPath[1024];						// arbitary length

    // count of uninstalls
    c = 0;

    // loop to unregister w.r.t all usage count
    while ( TRUE ) {

        // un-register the driver
        f = SQLRemoveDriver( pDriverName, FALSE, &y );

        // success
        if( f == TRUE ) {

            ++ c;
            continue;
        }

        // failure or driver has been uninstalled completely
        else {

            // find nature of error
            SQLInstallerError ( 1, &y, szPath, 512, &x );

            // check if driver not found
            if ( y == 6 )
                break;						// uninstallation complete

            // show status
            printf ( "Unregister status Code: %d, Msg: %s\n", y, szPath );
            return;
        }
    }

	// check if driver has been unregistered at least once
    if ( c > 0 )
        printf ( "%s unregistered successfully (%d)\n", pDriverName, c );

    return;
}


// -----------------------------------------------------------------------
// main
// -----------------------------------------------------------------------

void main ( int argc, char* argv[] )
{
    int             i;
    char            drivername[256];
	char            dllname[256];
	char            dllpath[256];


	// banner
	printf ( "ODBCREG - to register or unregister ODBC driver\n\n" );

	// syntax
	if ( argc == 1 ) {
        printf ( "USAGE: ( to install )\n" );
		printf ( "       ODBCREG /i driver-name dll-name dll-path\n" );
		printf ( "       ODBCREG /i \"General ODBC Driver 0\" ODBCDRV0.DLL C:\\TEMP\n" );
		printf ( "       ODBCREG /i \"General ODBC Driver 1\" ODBCDRV1.DLL C:\\TEMP\n" );
		printf ( "       ODBCREG /i (use default values for ODBCDRV0)\n\n" );
        printf ( "       ( to uninstall )\n" );
		printf ( "       ODBCREG /u driver-name\n" );
		printf ( "       ODBCREG /u \"General ODBC Driver 0\"\n" );
		printf ( "       ODBCREG /u \"General ODBC Driver 1\"\n" );
		printf ( "       ODBCREG /u (use default value General ODBC Driver)\n\n" );
		return;
	}

	// check if install
	if ( stricmp ( argv[1], "/i" ) == 0 || stricmp ( argv[1], "-i" ) == 0 ) {

			// driver name

		if ( argc >= 3 )
			strcpy ( drivername, argv[2] );						// user-specified value
		else 
			strcpy ( drivername, DRIVER_NAME );					// use default value

			
			// driver DLL

		if ( argc >= 4 )
			strcpy ( dllname, argv[3] );						// user-specified value
		else 
			strcpy ( dllname, DLL_NAME );						// use default value

			
			// dll-path

		if ( argc >= 5 )
			strcpy ( dllpath, argv[4] );						// user-specified value
		else
			GetCurrentDirectory ( sizeof(dllpath), dllpath );	// use current directory

			// confirm

		printf ( "Proceeding to register... \n\n" );
		printf ( "  driver: %s\n", drivername );
		printf ( "     dll: %s\n", dllname );
		printf ( "    path: %s\n\n", dllpath );

		printf ( "Confirm(y/n)" );
		if (( i = getch()) == 0 ) i = getch();
		printf ( "\n" );

		if (  i != 'Y' && i != 'y' ) {
			printf ( "Cancelled.\n" );
			return;
		}

			// install

		ODBCRegDriver ( drivername, dllname, dllpath );
	}

	// check if un-install
	else if ( stricmp ( argv[1], "/u" ) == 0 || stricmp ( argv[1], "-u" ) == 0 ) {

		// driver name
		if ( argc >= 3 )
			strcpy ( drivername, argv[2] );						// user-specified value
		else 
			strcpy ( drivername, DRIVER_NAME );					// use default value

		printf ( "Proceeding to un-register... \n\n" );
		printf ( "  driver: %s\n\n", drivername );

		printf ( "Confirm(y/n)" );
		if (( i = getch()) == 0 ) i = getch();
		printf ( "\n" );

		if (  i != 'Y' && i != 'y' ) {
			printf ( "Cancelled.\n" );
			return;
		}

			// uninstall

		ODBCUnRegDriver ( drivername );
	}

	// neither /i nor /u specified
	else {

		printf ( "USAGE: ODBCREG /i driver-name dll-name dll-path     ( to install )\n" );
		printf ( "       ODBCREG /u driver-name                       ( to uninstall )\n" );
		return;
	}
}

