// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

#ifndef TYPES_H
#define TYPES_H

typedef char         	        Char;
typedef short		            Word;
typedef long			        Long;

typedef unsigned char           UChar;
typedef unsigned short          UWord;
typedef unsigned long           ULong;

typedef Char *                  StrPtr;
typedef const Char *            CStrPtr;

enum    eGoodBad    {   GOOD        = 0,    BAD         };

#endif // TYPES_H

