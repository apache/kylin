// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

// ----------------------------------------------------------------------------
//
// File:    XMLTEST.CPP
//
// Author:  Vikash K Agarwal
//
// Notes:   To test the XMLNode class, XMLLex and XMLParser
//
// ----------------------------------------------------------------------------


// ------------------------------- include files ------------------------------
#include <conio.h>
#include <io.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <fcntl.h>

#include <xmltree.hpp>
#include <xmllex.hpp>
#include <xmlparse.hpp>


// --------------------------- function prototypes ----------------------------
void    testlex             ( char* pBuf, char* pFileName );
void    testparser          ( char* pBuf, char* pFileName );
void    testtree            ( void );


// ----------------------------------------------------------------------------
// to test the lexer, tokenize a stream and show the tokens
// ----------------------------------------------------------------------------

void testlex ( char* pBuf, char* pFileName )
{
	// note
	// can take input buffer from
	// 1. specified buffer
	// 2. specified XML file
	// 3. use a default buffer

    int         handle;
    int         t, size;
    char*       xbuf = NULL;
    char*       token = NULL;    

    XMLLex*     xl;

    // check if buffer specified
    if ( pBuf ) {

        // use the buffer
        xbuf = pBuf;
        size = -1;
    }

    // use file if specified
    else if ( pFileName ) {

        // debug
        printf ( "Opening file: %s\n", pFileName );

        // open file
        if (( handle = _open ( pFileName, O_RDONLY|O_BINARY )) == -1 ) {
            printf ( "Error: could not open file: %s\n", pFileName );
            return;
        }

        // get file size
        size = lseek ( handle, 0, SEEK_END );

        // go to begining
        lseek ( handle, 0, SEEK_SET );

        // allocate
        xbuf = new char[size];

        // check
        if ( xbuf == NULL ) {

            _close ( handle ); handle = -1;

            printf ( "Error: Memory allocation with new failed\n" );
            return;
        }

        // debug
        printf ( "Reading file (size: %d)\n", size );

        // read
        if (( t =  _read ( handle, xbuf, size )) != size ) {

            delete[] xbuf; xbuf = NULL;
            _close ( handle ); handle = -1;

            printf ( "Error: read failed on file\n" );
            _close ( handle );
        }

        // close the file
        _close ( handle ); handle = -1;
    }

    // use a default buffer
    else  {

        size = -1;
        xbuf = "<ROOT><LEVEL1><LEVEL2><LEVEL3><LEVEL3a>abc</LEVEL3a><LEVEL3b>def</LEVEL3b><LEVEL3c></LEVEL3c></LEVEL3></LEVEL2></LEVEL1></ROOT>";
    }

    // allocate the XML parser
    xl = new XMLLex ( xbuf, size, NULL );

    // specify token holder
    xl->InitTokenHolder ( &token );

    // debug
    printf ( "Starting lexer ... " );

    // parse
    for ( t = 0;  xl->GetNextToken () != 0; t ++ )
        printf ( "%d: %s\n", t+1, token );

    printf ( "Total tokens: %d\n", t );

    // debug
    printf ( "complete\n" );

    // release buffer
    if ( size != -1 ) {
        delete[] xbuf;
        xbuf = NULL;
    }

    // release token holder
    if ( token ) delete[] token;

    // release parser
    if ( xl ) delete xl;
}


// ----------------------------------------------------------------------------
// to test the parser
// ---------------------------------------------------------------------------

void testparser ( char* pBuf, char* pFileName )
{
	// note
	// can take input buffer from
	// 1. specified buffer
	// 2. specified XML file
	// 3. use a default buffer

    int         handle;
    int         t, size;
    char*       xbuf = NULL;

    XMLNode*    n = NULL;
    XMLParser*  xp = NULL;

    // check if buffer specified
    if ( pBuf ) {

        // use the buffer
        xbuf = pBuf;
        size = -1;
    }

    // check if file specified
    else if ( pFileName ) {

        // debug
        printf ( "Opening file: %s\n", pFileName );

        // open file
        if (( handle = _open ( pFileName, O_RDONLY|O_BINARY )) == -1 ) {
            printf ( "Error: could not open file: %s\n", pFileName );
            return;
        }

        // get file size
        size = lseek ( handle, 0, SEEK_END );

        // go to begining
        lseek ( handle, 0, SEEK_SET );

        // allocate
        xbuf = new char[size];

        // check
        if ( xbuf == NULL ) {

            _close ( handle ); handle = -1;

            printf ( "Error: Memory allocation with new failed\n" );
            return;
        }

        // debug
        printf ( "Reading file (size: %d)\n", size );

        // read
        if (( t =  _read ( handle, xbuf, size )) != size ) {

            delete[] xbuf; xbuf = NULL;
            _close ( handle ); handle = -1;

            printf ( "Error: read failed on file\n" );
            _close ( handle );
        }

        // close the file
        _close ( handle ); handle = -1;
    }

    // use an internal bufffer
    else  {

        size = -1;
        xbuf = "<ROOT><LEVEL1><LEVEL2><LEVEL3><LEVEL3a>abc</LEVEL3a><LEVEL3b>def</LEVEL3b><LEVEL3c></LEVEL3c></LEVEL3></LEVEL2></LEVEL1></ROOT>";
    }

    // allocate the XML parser
    xp = new XMLParser ( xbuf, size );

    // debug
    printf ( "Starting parse ... " );

    // parse
    n = xp->GetObjNode ();

    // debug
    if ( n != NULL ) {
    
        // debug
        printf ( "success\n" );

        // show streaming warning if tree is large and streaming may take time
        if ( size != -1 && size > 100000 ) {

            printf ( "Tree quite big, confirm before streaming(Y/N)? " );

            if (( t = getch()) == 0 )  t = getch();
        }
        else
            t = 'Y';

        if ( t == 'Y' || t == 'y' ) {

            FILE* f;
            f = fopen ( "out.xml", "w" );

			// note that u can specify the file type and file handle. So u can specify
			// socket server type and sockserver class handle or
			// socket client type and sockclient class handle
            n->StreamToFile ( 0, _FILE_STDOUT, f  ? f : stdout );			

            if ( f ) fclose ( f );
        }
    }
    else
        printf ( "failed\n" );

    // release buffer
    if ( size != -1 ) {
        delete[] xbuf;
        xbuf = NULL;
    }

    // release node
    if ( n ) delete n;

    // release parser
    if ( xp ) delete xp;
}


// ----------------------------------------------------------------------------
// to test the XML tree ie the XMLNode class, sample to build a document using DOM
// ---------------------------------------------------------------------------

void testtree ( void )
{
    XMLNode*        root;
    XMLNode*        node1;
    XMLNode*        node2;
    XMLNode*        node3;
    XMLNode*        nodeattr;

    // create the root element
    root = XMLNode::CreateElement ( "ENVELOPE", NULL );

    // create the HEADER and append it to ENVELOPE
    node1 = XMLNode::CreateElement ( "HEADER", NULL );
    root->AppendChildNodeBeforeX( node1, NULL );

    // create the CONNECTID and append it to HEADER
    node2 = XMLNode::CreateElement ( "CONNECTID", "12345" );
    node1->AppendChildNodeBeforeX( node2, NULL );

    // create the BODY and append it to ENVELOPE
    node1 = XMLNode::CreateElement ( "BODY", NULL );
    root->AppendChildNodeBeforeX( node1, NULL );

    // create methodname tag and append it to BODY
    node2 = XMLNode::CreateElement ( "SQLExecStmt", NULL );
    node1->AppendChildNodeBeforeX( node2, NULL );

    // create STMT tag and append it to method name tag
    node3 = XMLNode::CreateElement ( "STMT", "SELECT * FROM authors" );
    node2->AppendChildNodeBeforeX( node3, NULL );

    // create and append the statement type as attribute
    nodeattr = XMLNode::CreateAttribute ( "Type", "General" );
    node1->AppendChildNodeBeforeX( nodeattr, NULL );

    // stream the tree to a file
    root->StreamToFile ( 0, _FILE_STDOUT, stdout );

    delete root;
}

void main( int argc, char* argv[] )
{
	// banner
	printf ( "XMLTest for testing lexer, parser and tree\n\n" );

	// lexer
	printf ( "------------------ Testing lexer ------------------\n" );

	// user file as input or default buffer
    if ( argc > 1 ) 
        testlex ( NULL, argv[1] );
    else
        testlex ( NULL, NULL );

	printf ( "---------------------------------------------------\n\n" );



	// parser
	printf ( "------------------ Testing parser ------------------\n" );
	printf ( "( parse and output to out.xml)\n" );

	// user file as input or default buffer
    if ( argc > 1 ) 
        testparser ( NULL, argv[1] );
    else
        testparser ( NULL, NULL );

	printf ( "---------------------------------------------------\n\n" );



	// tree building using DOM
	printf ( "-------------- Testing tree using DOM ---------------\n" );
	printf ( "( will create and stream to stdout )\n" );

	// create and stream sample request to stdout
	testtree ();

	printf ( "---------------------------------------------------\n\n" );
}




