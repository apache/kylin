// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

// ---------------------------------------------------------------------------------
//
// File:    TESTSVR.CPP
//
// Notes:   To demonstrate the basic functions required for connecting
//			using sockets. Essentially demonstrates the code snippet
//			described in the article. 
//			Serves the test client TESTCLI. receives a hello and sends
//			a hello, that is all.
//			It is not a full fledged client and is only present here
//			for beginning socket communication. 
//			Our driver and the other sample (XSOCKSVR) uses TSocket
//			class implemented in SOCK_SVR.CPP
//			TESTCLI exe must be run after this EXE is started.
// ----------------------------------------------------------------------------------



#include <stdio.h>
#include <winsock.h>

void main ( void )
{
	int				status;					// status or return values
	char			buf[128];				// buffer to recv request
    SOCKET			listen_sckt;			// socket handle to listen
	SOCKET			conn_sckt;				// socket handle for connection
	WSADATA			wsadata;				// winsock requirement for startup
    SOCKADDR_IN		listen_addr;			// structure for IP, port etc.

	// winsock initialization, specify the version required
    status = WSAStartup ( MAKEWORD( 1, 1 ), &wsadata );

	// create a socket, no address associated as yet
    listen_sckt = socket ( AF_INET, SOCK_STREAM, 0 );  

    // prepare to bind socket to a port on any IP for the machine
    listen_addr.sin_family         = AF_INET;			// address family
    listen_addr.sin_port           = htons ( 9999 );	// port number
    listen_addr.sin_addr.s_addr    = htonl ( 0 );		// any IP address

    // bind the socket to the address family, port, IP
    status = bind ( listen_sckt, ( const struct sockaddr* )&listen_addr, 
		            sizeof(listen_addr));

    // switch to listen mode to allow connections
    status = listen ( listen_sckt, 1 );

    // wait and accept connections
	conn_sckt = accept ( listen_sckt, NULL, NULL );

	// recv request from client
    status = recv ( conn_sckt, buf, 512, 0 );

	// send a hello to client
    status = send ( conn_sckt, "Hello Client", 12, 0 );

	// initiate a shutdown for both send and recv
	status = shutdown ( conn_sckt, 0x02 );                 

	// close the client connection socket
	status = closesocket( conn_sckt );

	// close the listening connection socket
	status = closesocket( listen_sckt );

	// complete
	printf ( "Done.\n" );
}