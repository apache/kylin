// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji

// THIS IS A READ-ONLY FILE.  To modify use XMLPARSE.TPL or XMLPARSE.Y

// $Workfile$ .. $Revision$ .. $Date$

#include <stdio.h>
#include <xmllex.hpp>
#include <xmlparse.hpp>

//#define PRINTRULE(x)		printf ( x )
#define PRINTRULE(x)		;


#define _START_TAG 501
#define _START_TAG_WITH_ATTR 502
#define _END_OF_START_TAG 503
#define _EMPTY_ELEMENT 504
#define _END_OF_EMPTY_ELEMENT 505
#define _END_TAG 506
#define _EQUALS 507
#define _QUOTED_STRING 601
#define _UNQUOTED_STRING 602
#ifndef YYSTYPE
#define YYSTYPE int
#endif
YYSTYPE yylval, yyval;
#define YYERRCODE 256


FILE *yytfilep;
char *yytfilen;
int yytflag = 0;
int svdprd[2];
char svdnams[2][2];

const int yyexca[] = {
  -1, 1,
  0, -1,
  -2, 0,
  0,
};

#define YYNPROD 14
#define YYLAST 110

const int yyact[] = {
       4,       5,      11,       3,      26,      19,       4,       5,
      23,       3,      16,       6,      15,       4,       5,      22,
       3,      18,      25,       4,       5,      24,       3,      12,
      13,       4,       5,       8,       3,       9,       2,      10,
       1,       0,       0,       0,       0,       0,      14,       0,
       0,       0,       0,       0,      21,       0,       0,       0,
       0,       0,       0,      14,       0,       0,       0,       0,
       0,       0,       0,       0,       0,       0,       0,       0,
       0,       0,       0,       0,       0,       0,       0,       0,
       0,       0,       0,       0,       0,       0,       0,       0,
       0,       0,       0,       0,       0,       0,       0,       0,
       0,       0,       0,       0,       0,       0,       0,       0,
       0,       0,       0,       0,       0,      20,       0,       0,
       0,       0,       0,       7,       0,      17,
};

const int yypact[] = {
    -476,   -1000,   -1000,   -1000,    -495,    -600,   -1000,    -483,
    -482,   -1000,    -493,    -490,   -1000,   -1000,   -1000,   -1000,
    -501,    -492,    -593,   -1000,    -485,    -488,    -597,   -1000,
   -1000,   -1000,   -1000,
};

const int yypgo[] = {
       0,      32,      29,      27,      31,
};

const int yyr1[] = {
       0,       1,       2,       2,       2,       2,       2,       2,
       2,       2,       3,       3,       4,       4,
};

const int yyr2[] = {
       0,       1,       1,       2,       3,       3,       3,       4,
       5,       5,       1,       2,       3,       4,
};

const int yychk[] = {
   -1000,      -1,      -2,     504,     501,     502,     506,     602,
      -3,      -2,      -4,     602,     506,     506,      -2,     505,
     503,     602,     507,     506,     602,      -3,     507,     601,
     506,     506,     601,
};

const int yydef[] = {
       0,      -2,       1,       2,       0,       0,       3,       0,
       0,      10,       0,       0,       4,       5,      11,       6,
       0,       0,       0,       7,       0,       0,       0,      12,
       8,       9,      13,
};

// Template for YACC (XMLPARSE.TPL) --- generates actual file ( XMLPARSE.CXX )
// The CXX file is parsed by YACCFILT which clears any unwanted lines and errors
// ----------------------------------------------------------------------------

bool XMLParser::Parse (void)
{
	int*			yyps;

	XResult*		yypvt;
	XResult*		yypv;

	const int*		yyxi;

	int				yyj;
	int				yym;
	int				yystate;
	int				yyn;
	int				token;
	bool			eosdone = false;
	bool			rc;

    yystate = 0;

	yyval.Reset ();

    token = -1;

    	// initialize the state stack and value stack position pointer

    yyps = &yys[-1];
    yypv = &yyv[-1];

yystack:                        // fetch token and push into stack

    ++ yyps;

    if ( yyps > &yys[YYMAXDEPTH-1] )
        return SetErrMsg ( grStackOverflow );

    *yyps = yystate;

    ++ yypv;
    *yypv = yyval;

    yyn = yypact[yystate];

    if (yyn <= YYFLAG) 
		goto yydefault;

    if ( token < 0 ) {

		token = LexToken ();

		if ( token <= 0 ) {

			if ( vLex.IsLexError())
				return false;					// msg from Lex already captured by us
		}
	}

	yyn += token;

	if (( yyn < 0 ) || ( yyn >= YYLAST ))
		goto yydefault;

    yyn = yyact[yyn];

    if ( yychk[yyn] == token ) {				// valid shift

        token = -1;
		yyval.CopyTokenValue ( yylval );		// ?????? original behaviour yyval = yylval;

        yystate = yyn;

        goto yystack;
    }

yydefault:

    yyn = yydef[yystate];

    if ( yyn == -2 ) {

        if ( token < 0 ) {

			token = LexToken ();

			if ( token <= 0 ) {

				if ( vLex.IsLexError())
					return false;				// error already captured by us
			}
		}

		yyxi = yyexca;

        while ((*yyxi != (-1)) || 
               (yyxi[1] != yystate))
            yyxi += 2;
        
        while(*(yyxi += 2) >= 0)
            if (*yyxi == token)
                break;
        
        yyn = yyxi[1];

        if (yyn < 0 ) 
			return true;						// SUCCESS!
    }

    if (yyn == 0)
        return SetErrMsg ( grXMLParseError );

        // reduction by production yyn

    yyps -= yyr2[yyn];
    yypvt = yypv;
    yypv -= yyr2[yyn];

    // yyval = yypv[1];              --- original behavious --- not required in very case, only if no other reduction takes place

    yym   = yyn;

    	// consult goto table to find next state

    yyn   = yyr1[yyn];
	yyj   = ( int )( yypgo[yyn] + *yyps + 1 );
    
	if ((yyj >= YYLAST) || (yychk[yystate = yyact[yyj]] != -yyn)) 
        yystate = yyact[yypgo[yyn]];

    rc = true;

    	// execute action for rule m

    switch (yym) {

        
case 1:{ PRINTRULE( "\nR: Reduce to document" ); rc = ActionReduceRoot( yyval, &yypvt[-0] ); } break;
case 2:{ PRINTRULE( "\nR: Empty element\n" );  rc = ActionReduceElement ( yyval, 0, true, &yypvt[-0], 0, 0, 0, 0 ); } break;
case 3:{ PRINTRULE( "\nR: Start and End tag\n" ); rc = ActionReduceElement ( yyval, 0, false, &yypvt[-1], 0, 0, 0, &yypvt[-0] ); } break;
case 4:{ PRINTRULE( "\nR: Start tag ... string ... end tag \n" );  rc = ActionReduceElement ( yyval, 0, false, &yypvt[-2], 0, &yypvt[-1], 0, &yypvt[-0] ); } break;
case 5:{ PRINTRULE( "\nR: Start tag ... element ... end tag \n" ); rc = ActionReduceElement ( yyval, 0, false, &yypvt[-2], 0, 0, &yypvt[-1], &yypvt[-0] ); } break;
case 6:{ PRINTRULE( "\nEmpty element (wa)\n" );  rc = ActionReduceElement ( yyval, 0, true, &yypvt[-2], &yypvt[-1], 0, 0, 0 ); } break;
case 7:{ PRINTRULE( "\nStart(wa) and End tag\n" );  rc = ActionReduceElement ( yyval, 0, false, &yypvt[-3], &yypvt[-2], 0, 0, &yypvt[-0] ); } break;
case 8:{ PRINTRULE( "\nStart tag(wa) ... string ... end tag \n" ); rc = ActionReduceElement ( yyval, 0, false, &yypvt[-4], &yypvt[-3], &yypvt[-1], 0, &yypvt[-0] ); } break;
case 9:{ PRINTRULE( "\nStart tag(wa) ... element ... end tag \n" ); rc = ActionReduceElement ( yyval, 0, false, &yypvt[-4], &yypvt[-3], 0, &yypvt[-1], &yypvt[-0] ); } break;
case 10:{ PRINTRULE( "\nElement to element\n" ); yyval = yypvt[-0]; } break;
case 11:{ PRINTRULE( "\nList and another element\n" );  rc = ActionReduceElementList ( yyval, &yypvt[-1], &yypvt[-0] ); } break;
case 12:{ PRINTRULE( "\nAttr\n" );  rc = ActionReduceAttr ( yyval, 0, &yypvt[-2], &yypvt[-0] ); } break;
case 13:{ PRINTRULE("\nAttrs Attr\n" );  rc = ActionReduceAttr ( yyval, &yypvt[-3], &yypvt[-2], &yypvt[-0] ); } break;
		default: { yyval = yypv[1]; }
    }

    if (rc == false)
		return false;

    goto yystack;
}

// End-of-file

