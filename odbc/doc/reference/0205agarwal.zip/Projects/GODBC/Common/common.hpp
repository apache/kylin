// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

// ---------------------------------------------------------------------------------
//
// File:    COMMON.HPP
//
// Author:  Vikash K Agarwal
//
// Notes:   Contains common functions required by various modules
//
// ----------------------------------------------------------------------------------

// ------------------------ common includes ----------------------------
#include <char.h>

// ------------------------ common functions ----------------------------
void        StrMake         ( char*& pDest, const char* pSrc );
