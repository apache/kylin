// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

// ---------------------------------------------------------------------------------
//
// File:    COMMON.CPP
//
// Author:  Vikash K Agarwal
//
// Notes:   Contains common functions required by various modules
//
// ----------------------------------------------------------------------------------

// -------------------------- include files ---------------------------
#include <string.h>

// ----------------------------------------------------------------------------
// to create a copy of a given string, allocation done in this function
// ----------------------------------------------------------------------------

void StrMake ( char*& pDest, const char* pSrc )
{
	// check src
	if ( pSrc ) {
		pDest = new char[strlen(pSrc)+1];					// allocate and copy
		strcpy ( pDest, pSrc ); 
    }
    else
        pDest = NULL;										// set target to empty
}
