// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

// ----------------------------------------------------------------------------
//
// File:        Client.cpp
//
// Purpose:     A simple ODBC client
//
// Author:      Vikash K Agarwal
//
// Notes:       the result of each function is taken into a variable and checked
//              in the subsequent lines, to produce a compressed code snippet
//              for the article without error checking code.
//
//              _SHOW_FULL_RESULTS - if this is defined, the client will
//              show all the cols and rows obtained otherwise it will
//              show just the first col name and value
//
//              _CONNECT_WITH_PROMPT - if defined the SQLDriverConnect
//              is not given any details of the target driver or connection 
//              params, all these r obtained by prompting the user
//              and allowing him to choose a DSN. This is done by the
//              driver manager followed by the specific driver if required.
//              otherwise u need to specify the driver and if possible
//              the connection params. I have used SQL server in this case
//              and provided the necessary params like SERVER, DATABASE, UID & PWD
//
// ----------------------------------------------------------------------------

// --------------------------------- include files ----------------------------
#include <conio.h>
#include <stdio.h>
#include <tchar.h>
#include <stdlib.h>

#include <windows.h>

#include <sqlext.h>                                     // required for ODBC calls

// ------ whether to show just first col of first row OR full result set ------
#define _SHOW_FULL_RESULTS 

// ----- whether to ask user for DSN and connection parameters OR specify -----
#define _CONNECT_WITH_PROMPT        1

// ------------- maximum length to be displayed for a column ------------------
#define _DISPLAY_MAX				64


// -------------------- macro to handle error situations ----------------------
#define ODBC_CHK_ERROR(hType,hValue,iStatus,szMsg)          \
                    {\
                        if ( status != SQL_SUCCESS ) {\
                            ShowDiagMessages ( hType, hValue, iStatus, szMsg );\
                        }\
                        if ( status == SQL_ERROR ) {\
                            goto Cleanup;\
                        }\
                    }

// ---------------------------------- structure -------------------------------
typedef struct BindColInfo {
	SQLSMALLINT			iColTitleSize;				// size of column title
	char*				szColTitle;					// column title
    SQLSMALLINT	        iColDisplaySize;            // size to display
	char*				szColData;                  // display buffer  
	SQLINTEGER          indPtr;                     // size or null indicator
	BOOL                fChar;                      // character col flag
	struct BindColInfo* next;						// linked list
} BIND_COL_INFO;

// -------------------------- function prototypes -----------------------------
void        ShowDiagMessages        ( SQLSMALLINT hType, SQLHANDLE hValue, SQLRETURN iStatus, char* szMsg );

SQLRETURN	ShowFullResults			( HSTMT hStmt );
void		FreeBindings			( BIND_COL_INFO* pBindColInfo );

// ----------------------------------------------------------------------------
// main
// ----------------------------------------------------------------------------

void main ( int argc, char* argv[] )
{
    SQLRETURN       status;

    SQLHANDLE       hEnv = 0;
    SQLHANDLE       hConn = 0;
    SQLHANDLE       hStmt = 0;

    SQLTCHAR        szConnStrOut[1024];

    SQLSMALLINT     x;

    // startup banner
    printf ( "General ODBC Client\n\n" );

    // check if query has been specified on command line
    if ( argc < 2 ) {
        printf ( "USAGE:    Client <query_statement>\n" );
        printf ( "EXAMPLE:  Client \"SELECT * FROM employee\"\n" );
        printf ( "          Client \"SELECT * FROM pubs..employee\"\n\n" );
        return;
    }

    // show query to be executed
    printf ( "Query: %s\n", argv[1] );


            // BEFORE U CONNECT

    // allocate ENVIRONMENT
    status = SQLAllocHandle ( SQL_HANDLE_ENV, SQL_NULL_HANDLE, &hEnv );

    // check for error
    ODBC_CHK_ERROR(SQL_HANDLE_ENV,hEnv,status,"");

	// set the ODBC version for behaviour expected
	status = SQLSetEnvAttr ( hEnv,  SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC2, 0 );

    // check for error
    ODBC_CHK_ERROR(SQL_HANDLE_ENV,hEnv,status,"");

    // allocate CONNECTION
    status = SQLAllocHandle ( SQL_HANDLE_DBC, hEnv, &hConn );

    // check for error
    ODBC_CHK_ERROR(SQL_HANDLE_ENV,hEnv,status,"");

#ifdef  _CONNECT_WITH_PROMPT

    // ----------- real connection takes place at this point 
    // ----------- option 1: user is prompted for DSN & options
    
    status = SQLDriverConnect ( hConn, GetDesktopWindow(), 
                                ( unsigned char* )"", 
                                SQL_NTS, szConnStrOut, 1024, &x, 
                                SQL_DRIVER_COMPLETE );
 

#else       // ----------- OR

    // ----------- real connection takes place at this point
    // ----------- option 2: all connection option for SQL server driver specified
    status = SQLDriverConnect ( hConn, GetDesktopWindow(), 
                                ( unsigned char* )"DRIVER={SQL Server};SERVER=VIKASH;DATABASE=pubs;UID=sa;PWD=;", 
                                SQL_NTS, szConnStrOut, 1024, &x, 
                                SQL_DRIVER_COMPLETE );
#endif

    // check for error
    ODBC_CHK_ERROR(SQL_HANDLE_DBC,hConn,status,"");


            // ???? CONGRATUALTIONS ---- u r connected to a DBMS via an ODBC driver

    // allocate STATEMENT
    status = SQLAllocHandle ( SQL_HANDLE_STMT, hConn, &hStmt );

    // check for error
    ODBC_CHK_ERROR(SQL_HANDLE_DBC,hConn,status,"");

    // execute the statement
    status = SQLExecDirect ( hStmt, ( unsigned char* )argv[1], SQL_NTS );

    // check for error
    ODBC_CHK_ERROR(SQL_HANDLE_STMT,hConn,status,"");
            
            // RESULTS READY

#ifdef  _SHOW_FULL_RESULTS						

	// show the full results row by row
	status = ShowFullResults ( hStmt );
			
    // check for error
    ODBC_CHK_ERROR(SQL_HANDLE_STMT,hStmt,status,"");

#else										// show just the first col of the first row

	short			iColCount;
	long			i;
    SQLTCHAR        szColTitle[64];
    SQLTCHAR        szColData[256];

    // get number of cols
    status = SQLNumResultCols ( hStmt, &iColCount );

    // check for error
    ODBC_CHK_ERROR(SQL_HANDLE_STMT,hConn,status,"");

    // get the title of first col ( first 64 bytes only )
    status = SQLColAttribute ( hStmt, 1, SQL_DESC_NAME, szColTitle, sizeof(szColTitle), &x, NULL );

    // check for error
    ODBC_CHK_ERROR(SQL_HANDLE_STMT,hConn,status,"");

    // bind an arbitray size buffer for obtaining col data
    status = SQLBindCol ( hStmt, 1, SQL_C_TCHAR, (SQLPOINTER)szColData, sizeof(szColData), &i );

    // check for error
    ODBC_CHK_ERROR(SQL_HANDLE_STMT,hConn,status,"");

    // fetch the first row
    status = SQLFetch ( hStmt );

    // check for error
    ODBC_CHK_ERROR(SQL_HANDLE_STMT,hConn,status,"");

    // show the value of the first col for the first row
    printf ( "Row:1, Col:1    Title: %s,   Value: %s", szColTitle, szColData );

#endif

Cleanup:

    // release statement
    if ( hStmt )
        SQLFreeStmt ( hStmt, SQL_CLOSE );

    // release connection
    if ( hConn ) {

		SQLDisconnect ( hConn );
		SQLFreeConnect ( hConn );
	}

    // release environment
	if ( hEnv ) 
		SQLFreeEnv ( hEnv );

    return;
}

// ----------------------------------------------------------------------------
// to display the full results row by row
// ----------------------------------------------------------------------------

SQLRETURN	ShowFullResults ( HSTMT hStmt )
{
	int					i, iCol;
	int					key, rows;

	BIND_COL_INFO*		head;
	BIND_COL_INFO*		last;
	BIND_COL_INFO*		curr;

    SQLRETURN			status;
	SQLSMALLINT			iType;
	SQLSMALLINT			iColCount;

	// initializations
	head = NULL;

			// ALLOCATE SPACE TO FETCH A COMPLETE ROW

	// get number of cols
    if (( status = SQLNumResultCols ( hStmt, &iColCount )) != SQL_SUCCESS )
		return status;

	// loop to allocate binding info structure
	for ( iCol = 1; iCol <= iColCount; iCol ++ ) {

        // alloc binding structure
		curr = ( BIND_COL_INFO* )calloc ( 1, sizeof(BIND_COL_INFO));
        if ( curr == NULL ) {
            fprintf ( stderr, "Out of memory!\n" );
            return SQL_SUCCESS;							// its not an ODBC error so no diags r required
        }

        // maintain link list
		if ( iCol == 1 )
			head = curr;								// first col, therefore head of list
		else
			last->next = curr;							// attach

		last = curr;									// tail    

		// get column title size
		if (( status = SQLColAttribute ( hStmt, iCol, SQL_DESC_NAME, NULL, 0, &( curr->iColTitleSize ), NULL )) != SQL_SUCCESS ) {
			FreeBindings ( head );
			return status;
		}
		else ++ curr->iColTitleSize;					// allow space for null char

		// allocate buffer for title
		curr->szColTitle  = ( char* ) calloc ( 1, curr->iColTitleSize * sizeof( char ));
        if ( curr->szColTitle == NULL ) {
			FreeBindings ( head );
            fprintf ( stderr, "Out of memory!\n" );
            return SQL_SUCCESS;							// its not an ODBC error so no diags r required
        }

		// get column title
		if (( status = SQLColAttribute ( hStmt, iCol, SQL_DESC_NAME, curr->szColTitle, curr->iColTitleSize, &( curr->iColTitleSize ), NULL )) != SQL_SUCCESS ) {
			FreeBindings ( head );
			return status;
		}


		// get col length 
		if (( status = SQLColAttribute ( hStmt, iCol, SQL_DESC_DISPLAY_SIZE, NULL, 0, NULL, &( curr->iColDisplaySize ))) != SQL_SUCCESS ) {
			FreeBindings ( head );
			return status;
		}

		// arbitrary limit on display size
		if ( curr->iColDisplaySize > _DISPLAY_MAX )  curr->iColDisplaySize = _DISPLAY_MAX;

		// allocate buffer for col data + NULL terminator
		curr->szColData = ( char* ) calloc ( 1, ( curr->iColDisplaySize + 1 ) * sizeof(char));
        if ( curr->szColData == NULL ) {
			FreeBindings ( head );
            fprintf ( stderr, "Out of memory!\n" );
            return SQL_SUCCESS;							// its not an ODBC error so no diags r required
        }

		// get col type, not used now but can be checked to print value right aligned etcc
		if (( status = SQLColAttribute ( hStmt, iCol, SQL_DESC_CONCISE_TYPE, NULL, 0, NULL, &iType )) != SQL_SUCCESS ) {
			FreeBindings ( head );
			return status;
		}

        // set col type indicator in struct
		curr->fChar = ( iType == SQL_CHAR || iType == SQL_VARCHAR || iType == SQL_LONGVARCHAR );

		// bind the col buffer so that the driver feeds it with col value on every fetch and use generic char binding for very column
		if (( status = SQLBindCol ( hStmt, iCol, SQL_C_CHAR, ( SQLPOINTER )curr->szColData, ( curr->iColDisplaySize+1 ) * sizeof(char), &( curr->indPtr ))) != SQL_SUCCESS ) {
			FreeBindings ( head );
			return status;
		}
	}

	// number of rows to show in one shot
	rows = 1;

	// loop to print all the rows one by one
	for ( i = 1, rows = 1; TRUE; i ++ ) {

		// fetch the next row
		if (( status = SQLFetch ( hStmt )) == SQL_NO_DATA_FOUND )
			break;													// no more rows so break

		// check for error
		else if ( status == SQL_ERROR ) {							// fetch failed
			FreeBindings ( head );
			return status;
		}

		// loop to print each column
		for ( curr = head, iCol = 0; iCol < iColCount; iCol ++, curr = curr->next )
			printf ( "%-32s: %s\n", curr->szColTitle, curr->szColData );		// check col type basically char or non-char

		// row separator
		printf ( "\n" );

		// wait for a key if required
		if ( i%rows == 0 ) {

			// message
 			printf ( "press any key ( 1...9 - no. of rows to show at a time, ESC quit )? " ); 

			// get from user
			if (( key = getch()) == 0 ) key = getch();

			// check key
			if ( key >= '1' && key <= '9' ) {
				i    = 0;							// reset count
				rows = key-'0';						// rows to show in one shot
			}
			else if ( key == 27 ) {
				printf ( "User break\n" );
				break;
			}

			// leave some space
			printf ("\n\n" );
		}
	}

	// free the allocated bindings
	FreeBindings ( head );

	return SQL_SUCCESS;
}


// ----------------------------------------------------------------------------
// to free the col info allocated by ShowFullResults
// ----------------------------------------------------------------------------

void FreeBindings ( BIND_COL_INFO* pBindColInfo )
{
	BIND_COL_INFO* next;

	// precaution 
	if ( pBindColInfo ) {

		do {

			// get the next col binding
			next = pBindColInfo->next;

			// free any buffer for col title
			if ( pBindColInfo->szColTitle ) {
				free ( pBindColInfo->szColTitle );
				pBindColInfo->szColTitle = NULL;
			}

			// free any col data
			if ( pBindColInfo->szColData ) {
				free ( pBindColInfo->szColData );
				pBindColInfo->szColData = NULL;
			}

			// free the current binding
			free ( pBindColInfo );

			// make next the current
			pBindColInfo = next;

		} while ( pBindColInfo );
	}
}

// ----------------------------------------------------------------------------
// to show the ODBC diagnostic messages
// ----------------------------------------------------------------------------

void ShowDiagMessages ( SQLSMALLINT hType, SQLHANDLE hValue, SQLRETURN iStatus, char* szMsg )
{
    SQLSMALLINT	iRec = 0;
    SQLINTEGER	iError;
    SQLTCHAR    szMessage[1024];
    SQLTCHAR    szState[SQL_SQLSTATE_SIZE];

    // header
    printf ( "\nDiagnostics:\n" );

    // in case of an invalid handle, no message can be extracted
	if ( iStatus == SQL_INVALID_HANDLE ) {
        fprintf ( stderr, "ODBC Error: Invalid handle!\n" );
        return;
    }

    // loop to get all diag messages from driver/driver manager
    while( SQLGetDiagRec ( hType, hValue, ++ iRec, szState, &iError, szMessage, (SQLSMALLINT)(sizeof(szMessage) / sizeof(TCHAR)), ( SQLSMALLINT* )NULL) == SQL_SUCCESS )
        _ftprintf ( stderr, TEXT("[%5.5s] %s (%d)\n"), szState, szMessage, iError );

    // gap
    printf ( "\n" );
}

