---
layout: docs30
title:  Install Ranger Plugin
categories: howto
permalink: /docs30/howto/howto_install_ranger_kylin_plugin.html
---

Please refer to [https://cwiki.apache.org/confluence/display/RANGER/Kylin+Plugin](https://cwiki.apache.org/confluence/display/RANGER/Kylin+Plugin).
