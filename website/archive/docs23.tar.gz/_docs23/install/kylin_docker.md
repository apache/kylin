---
layout: docs23
title:  "Run Kylin with Docker"
categories: install
permalink: /docs23/install/kylin_docker.html
version: v1.5.3
since: v1.5.2
---

Apache Kylin runs as a client of Hadoop cluster, so it is reasonable to run within a Docker container; please check [this project](https://github.com/Kyligence/kylin-docker/) on github.
