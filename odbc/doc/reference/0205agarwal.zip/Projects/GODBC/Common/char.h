// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

#ifndef CHAR_H
#define CHAR_H

#define EOS                 ((char) '\0')
#define C_IGNORE            ((char) -1)
#define C_EOF               ((char) '\x1a')

#define C_ZERO			    ((char) '0')
#define	C_ONE 			    ((char) '1')
#define	C_TWO 			    ((char) '2')
#define	C_THREE 		    ((char) '3')
#define	C_FOUR			    ((char) '4')
#define	C_FIVE			    ((char) '5')
#define	C_SIX 			    ((char) '6')
#define	C_SEVEN 		    ((char) '7')
#define	C_EIGHT 		    ((char) '8')
#define	C_NINE			    ((char) '9')

#define	C_SPACE 		    ((char) ' ')
#define C_TAB               ((char) '\t')

#define	C_MINUS 		    ((char) '-')
#define	C_HYPHEN		    ((char) '-')
#define	C_PLUS			    ((char) '+')
#define	C_DIVIDE	        ((char) '/')
#define	C_SLASH 	        ((char) '/')
#define	C_MULT  	        ((char) '*')
#define	C_STAR  	        ((char) '*')
#define	C_HASH  	        ((char) '#')
#define	C_POWER 	        ((char) '^')
#define	C_CARET 	        ((char) '^')
#define	C_PERCENT           ((char) '%')
#define C_EQUAL             ((char) '=')
#define C_LESSER            ((char) '<')
#define C_GREATER           ((char) '>')
#define C_AND               ((char) '&')
#define C_OR                ((char) '|')
#define C_NOT               ((char) '!')
#define C_AT                ((char) '@')
#define C_BACKSLASH         ((char) '\\')
#define	C_UNDERSCORE	    ((char) '_')

#define C_PERIOD            ((char) '.')
#define	C_DECIMAL		    ((char) '.')
#define C_COMMA             ((char) ',')
#define C_COLON             ((char) ':')
#define C_SEMI_COLON        ((char) ';')

#define	C_OPEN_ROUND	    ((char) '(')
#define	C_CLOSE_ROUND	    ((char) ')')

#define	C_OPEN_CURLY	    ((char) '{')
#define	C_CLOSE_CURLY	    ((char) '}')

#define	C_OPEN_SQUARE       ((char) '[')
#define	C_CLOSE_SQUARE	    ((char) ']')

#define	C_QUOTE             ((char) '\"')
#define	C_SNGL_QUOTE  	    ((char) '\'')

#define C_NEWLINE           ((char) '\n')
#define C_CR                ((char) '\r')

#define C_FORMFEED          ((char) '\f')
#define C_BKSP              ((char) '\b')

#define C_COMMENT           ((char) ';')
#define C_SEMICOLON         ((char) ';')
#define C_TOKEN_SEP         ((char) ':')
#define C_MACRO_SEP         ((char) ':')
#define C_SECTION_SEP       ((char) '[')
#define C_SECTION_SEP_END   ((char) ']')
#define C_SUBJECT_SEP       ((char) '{')
#define C_SUBJECT_SEP_END   ((char) '}')
#define C_MACRO_ID          ((char) '$')
#define C_FIELD_ID          ((char) '#')
#define C_METHOD_ID         ((char) '@')
#define C_SYSNAME           ((char) '')

#define C_TILDE             ((char) '~')
#define C_QUESTION          ((char) '?')
#define C_EXCLAIM           ((char) '!')
#define C_REVERSE_APOS      ((char) '`')
#define C_127               ((char) 127)

#define C_YES               ((char) 'Y')
#define C_NO                ((char) 'N')
#define C_ESC               ((char)  27)

#endif // CHAR_H

