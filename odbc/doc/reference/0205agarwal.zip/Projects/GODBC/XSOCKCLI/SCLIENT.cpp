// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

// ---------------------------------------------------------------------------------
//
// File:    SCLIENT.CPP
//
// Author:  Vikash K Agarwal
//
// Notes:   Socket client for testing the socket class (TSocketClient - XSOCLCLI.CPP)
//          The client creates dummy SOAP/XML requests
//          as is expected from the ODBC driver and post
//          it to the socket server on port 9999.
//
//          Note that the XSOCKSVR must be running
//          to receive the request and give an answer
//          The XSOCKSVR is actually simulating a DBMS
//          which is going to recv the SOAP/XML request
//          and answer in a agreed upon format
//
//          If u have doubts about the communication 
//          from the driver u can use this client and check
//          that out. On the other hand, if u have doubts
//          about ur server, u can use XSOCKSVR example and
//          check it out.    
//
//          The request response session can be dumped to screen
//          as well to a log file
//
//          I have avoided use of XMLTree and SOAP helper functions
//          to create request, to keep thing simple. The driver
//          uses these to construct the request.
//
//          I have provided three possible types of request that
//          can be generated from the driver. This can be seen 
//          in CreateRequest
//
// ----------------------------------------------------------------------------------

// ------------------------------- include files -----------------------------
#include <io.h>
#include <conio.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>

#include <winsock.h>
#include "sock_cli.hpp"

// ------------------------------ local defines -------------------------------
#define     _LOG_FILE_NAME          "xsockcli.log"

#define     _REQUEST_CONNECT        1			
#define     _REQUEST_TABLES         2
#define     _REQUEST_EXEC_STMT      3

// --------------------------- function prototypes  ---------------------------
int 		UserConfirm				( char* pMsg );
void        DumpBufferToScreen      ( char* pHeader, char* pBuf, int pBufSize );
void        ResetLogFile            ( void );
void        DumpBufferToLog         ( char* pHeader, char* pBuf, int pBufSize );
void        CreateRequest           ( int pReqType, char** pBuf, int* pBufSize );
void        TestRequestResponse     ( TSocketClient& sc, int pReqType, int pRepeatCount, bool fDumpReqToScr, bool fDumpRespToScr, bool fDumpReqToLog, bool fDumpRespToLog );

// --------------------------------------------------------------------
// to get yes/no from user before processding
// --------------------------------------------------------------------

int UserConfirm ( char* pMsg )
{
	int key;

	// show message
	printf ( "%s", pMsg );

	// get user choice
	if (( key = getch()) == 0 ) key = getch();

	// show key
	putchar ( key );
	putchar ( '\n' );

	return key;

}

// --------------------------------------------------------------------
// to dump a buffer to screen, for debugging
// --------------------------------------------------------------------

void DumpBufferToScreen ( char* pHeader, char* pBuf, int pBufSize )
{
    int i;

    // show header if one has been specified
    if( pHeader && *pHeader ) printf( "\n%s: ", pHeader );

    // show buffer char by char
    for ( i = 0; i < pBufSize; i ++ )  putchar ( pBuf[i]);

    // newline
    printf( "\n");
}

// --------------------------------------------------------------------
// to save the buffer to a log file, for later analysis
// --------------------------------------------------------------------

void DumpBufferToLog ( char* pHeader, char* pBuf, int pBufSize )
{
	int			h;	

    // open the log file
	h = _open ( _LOG_FILE_NAME, _O_CREAT | _O_RDWR | _O_APPEND | _O_TEXT, _S_IWRITE );

    // check
    if ( h != -1 ) {

        // dump header 
        if ( pHeader && *pHeader ) {

            _write ( h, "--------\n", 9 );
            _write ( h, pHeader, strlen ( pHeader ));
            _write ( h, "\n", 1 );
            _write ( h, "--------\n", 9 );
        }

        // dump the buffer 
        _write ( h, pBuf, pBufSize );

        // separator
        _write ( h, "\n\n", 2 );
        
        // close the file
        _close ( h );           
    }
}


// --------------------------------------------------------------------
// to create a request, basically to show kind of request expected from driver
// --------------------------------------------------------------------

void  CreateRequest ( int pReqType, char** pBuf, int* pBufSize )
{
    // note
    // I have purposely avoided the use of XMLTree class and SOAP helper
    // functions to create these SOAP/XML requests, to keep things simple.
    // The driver uses those. Also the dummy server uses these to 
	// construct the response

    char* buf;

    // caller safe
    *pBuf       = NULL;
    *pBufSize   = 0;

    switch ( pReqType ) {

    case _REQUEST_TABLES:
        buf     =       "<ENVELOPE><HEADER></HEADER><BODY>" \
                        "<SQLTables>" \
						"<VARIABLES>" \
                        "<CATALOG>%</CATALOG>" \
                        "<SCHEMA>user</SCHEMA>" \
                        "<TABLE>%</TABLE>" \
                        "<TABLETYPE></TABLETYPE>" \
						"</VARIABLES>" \
                        "</SQLTables>" \
                        "</BODY></ENVELOPE>";
        break;

    case _REQUEST_EXEC_STMT:

        buf     =       "<ENVELOPE><HEADER></HEADER><BODY>" \
                        "<SQLExecute>" \
                        "<STMT>SELECT * FROM employee</STMT>" \
						"<VARIABLES></VARIABLES>" \
                        "</SQLExecute>" \
                        "</BODY></ENVELOPE>";
        break;

    case _REQUEST_CONNECT:
    default:
        buf     =       "<ENVELOPE><HEADER></HEADER><BODY>" \
                        "<SQLConnect>" \
						"<VARIABLES>"
                        "<UID>user</UID>" \
                        "<PWD>user</PWD>" \
						"</VARIABLES>"
                        "</SQLConnect>" \
                        "</BODY></ENVELOPE>";
        break;
    }

    // allocate buffer
    *pBufSize   = strlen(buf);
    *pBuf       = new char[*pBufSize + 1];

    // copy the local buffer
    memcpy ( *pBuf, buf, *pBufSize );
    (*pBuf)[*pBufSize] = 0;
}

// --------------------------------------------------------------------
// to execute a request response between the socket client & server
// --------------------------------------------------------------------

void TestRequestResponse ( TSocketClient& sc, int pReqType, int pRepeatCount, bool fDumpReqToScr, bool fDumpRespToScr, bool fDumpReqToLog, bool fDumpRespToLog )
{
    int     i, y;
    int     reqsize, respsize;
    char*   reqbuf;
    char*   respbuf;

    // create a SOAP/XML request as per type specified
    CreateRequest ( pReqType, &reqbuf, &reqsize );

    // check
    if ( reqbuf == NULL || reqsize <= 0 ) {
        printf ( "Error: could not create request\n" );
        return;
    }

    // loop to repeat the test, number of times specified
    for ( i = 0; i < pRepeatCount; i ++ ) {

            // CONNECT

        if ( sc.SockCreateAndConnect () != TRUE ) {
            fprintf ( stderr, sc.GetErrMsg());
            return;
        }

        printf ( "------------------ Connected ... ----------------\n\n" ); 

            // REQUEST

        // signature
        if ( sc.WriteSignature () != TRUE ) {

            fprintf ( stderr, sc.GetErrMsg());
            return;
        }

        // post request
        if ( sc.SockWriteChunk ( reqbuf, reqsize, y ) == FALSE ) {

            fprintf ( stderr, sc.GetErrMsg());
            return;
        }

        // signature
        if ( sc.WriteSignature () != TRUE ) {

            fprintf ( stderr, sc.GetErrMsg());
            return;
        }

        // status
        printf ( "Test no.: %d, Request Type: %s, Status: sent, Size: %d\n", i+1, pReqType == _REQUEST_CONNECT ? "_REQUEST_CONNECT" : pReqType == _REQUEST_TABLES ? "_REQUEST_TABLES" : "_REQUEST_EXEC_STMT",  reqsize );

        // check if full dump of request required
        if ( fDumpReqToScr )
            DumpBufferToScreen ( "Request dump", reqbuf, reqsize );

        // check if full dump of request required in log file
        if ( fDumpReqToLog )
            DumpBufferToLog ( "Request dump", reqbuf, reqsize );

            // RESPONSE

        // read message from socket
        if ( sc.SockReadFullMsg ( respbuf, respsize ) != TRUE ) {

            fprintf ( stderr, sc.GetErrMsg());
            return;
        }

        // check if full dump of response required
        if ( fDumpRespToScr )
            DumpBufferToScreen ( "Response dump", respbuf, respsize );

        // check if full dump of response required in log file
        if ( fDumpRespToLog )
            DumpBufferToLog ( "Response dump", respbuf, respsize );

        // release response buffer
        if ( respbuf ) 
            delete[] respbuf;

            // DISCONNECT

        sc.SockClose ();

		// complete
		printf ( "\n------------------ Complete ... -----------------\n\n" );
    }

    // delete request buffer
    if ( reqbuf )
        delete[] reqbuf;    
}

// --------------------------------------------------------------------
// to test the socket client, main function
// --------------------------------------------------------------------

void TestSockAsClient ( char* s )
{
	int x;

    TSocketClient sc;

    // initialize
    sc.Initialize (( s ) ? s : "127.0.0.1", 9999 );
    
    // repeat-request response twice
    if (( x = UserConfirm ( "Send a connection request(Y/N)? " )) == 'Y' || x == 'y' )
		TestRequestResponse ( sc, _REQUEST_CONNECT, 1, TRUE, TRUE, TRUE, TRUE );
	else
		printf ( "\n" );

	// repeat-request response twice
	if (( x = UserConfirm ( "Send request for tables(Y/N)? " )) == 'Y' || x == 'y' )
		TestRequestResponse ( sc, _REQUEST_TABLES, 1, TRUE, TRUE, TRUE, TRUE );
	else
		printf ( "\n" );

	// repeat-request response twice
	if (( x = UserConfirm ( "Send request for stmt execution(Y/N)? " )) == 'Y' || x == 'y' )
		TestRequestResponse ( sc, _REQUEST_EXEC_STMT, 1, TRUE, TRUE, TRUE, TRUE );
	else
		printf ( "\n" );
}


// --------------------------------------------------------------------
// main entry point function
// --------------------------------------------------------------------

void main ( int argc, char* argv[] )
{
	// banner
	printf ( "XSOCKCLI - test socket client using XML/SOAP\n\n" );
	printf ( "Warning !!! please make sure the server is running on this machine - XSOCKSVR\n\n" );

    // initialize LIB
    TSocketClient::SockInitLib ();

    // test socket client
    TestSockAsClient (( argc > 1 ) ? argv[1] : NULL );

    // finalize lib
    TSocketClient::SockFinalizeLib ();
}
