// Sri Ganeshji : Sri Balaji : Sri Pitreshwarji : Sri Durgaji : Sri Venkateshwara

// ----------------------------------------------------------------------------
//
// File:		XMLLEX.HXX
//
// Purpose:     Inline functions for XMLLex class
//
// Author:		Vikash K Agarwal
//
// ---------------------------------------------------------------------------

#ifndef XMLLEX_HXX
#define XMLLEX_HXX

// -----------------------------------------------------------------------
// destructor
// -----------------------------------------------------------------------

inline XMLLex::~XMLLex (void)
{
	// the buffer has not been specified by the caller
    if ( vUserBuffer == false && vBuffer )  {

       delete[] vBuffer;
       vBuffer = NULL;
    }
}


// -----------------------------------------------------------------------
// lexer has encounter an error
// -----------------------------------------------------------------------

inline bool XMLLex::IsLexError (void)
{
    return vInError;
}


// -----------------------------------------------------------------------
// add the curr char from input stream to token
// -----------------------------------------------------------------------

inline void XMLLex::AddCurrCharToToken (void)
{
    // get and add the next char
	AddCharToToken ( GetNextChar());

    // move to next char in buffer
	IncrPos ();
}


// -----------------------------------------------------------------------
// check if no more data
// -----------------------------------------------------------------------

inline bool XMLLex::EndOfStream (void)
{
	return ( vCurPos >= vMaxPos );
}

// ----------------------------------------------------------------------
// to get the next char from input
// ----------------------------------------------------------------------

inline char XMLLex::GetNextChar ( void )
{
    return ( vBuffer && vCurPos < vMaxPos ) ? vBuffer[vCurPos] : 0;
}

// -----------------------------------------------------------------------
// to move the position counters by one
// -----------------------------------------------------------------------

inline void XMLLex::IncrPos (void)
{
    vCurPos ++;
}

#endif // XMLLEX_HXX

// End-of-file

